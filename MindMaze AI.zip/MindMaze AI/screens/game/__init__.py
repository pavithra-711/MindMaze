
CASE_TITLE = "The Midnight Murder"

CASE_INTRO = (
    "Dr. Adrian Vale, a famous scientist, was found dead "
    "in his locked mansion at 11:30 PM during a storm. "
    "Four people were in the mansion. Investigate the "
    "evidence and discover whose story does not add up."
)

CLUES = {
    "broken_clock": {
        "title": "The Broken Clock",
        "description": (
            "The study clock stopped at 10:45 PM. "
            "Its hands may have been moved before the "
            "body was discovered."
        ),
        "location": "Study",
    },
    "muddy_footprint": {
        "title": "Muddy Footprint",
        "description": (
            "A muddy shoeprint was found near the library "
            "window. The storm began around 10:00 PM."
        ),
        "location": "Library",
    },
    "torn_letter": {
        "title": "Torn Letter",
        "description": (
            "The letter reads: 'Meet me in the study "
            "before eleven. Come alone.' The signature "
            "is missing."
        ),
        "location": "Study",
    },
    "missing_key": {
        "title": "Missing Key",
        "description": (
            "The study's spare key is missing from its "
            "usual place. Someone may have entered or "
            "left the room without using the main door."
        ),
        "location": "Hallway",
    },
}

SUSPECTS = {
    "elena": {
        "name": "Elena Vale",
        "role": "The Daughter",
        "motive": "She argued with Adrian over his inheritance.",
        "alibi": "She claims she was in the drawing room at 10:45 PM.",
        "statement": (
            "I heard the grandfather clock strike eleven. "
            "I never entered the study that evening."
        ),
    },
    "marcus": {
        "name": "Marcus Reed",
        "role": "The Business Partner",
        "motive": "Adrian planned to expose a financial dispute.",
        "alibi": "He says he was in the conservatory during the storm.",
        "statement": (
            "I was nowhere near the study. I came here "
            "to discuss business, nothing more."
        ),
    },
    "iris": {
        "name": "Dr. Iris Shaw",
        "role": "The Research Assistant",
        "motive": "Adrian intended to publish research without crediting her.",
        "alibi": "She says she was organizing papers in the laboratory.",
        "statement": (
            "The study clock was already broken when "
            "I passed the hallway earlier."
        ),
    },
    "thomas": {
        "name": "Thomas Gray",
        "role": "The Butler",
        "motive": "Adrian threatened to dismiss him.",
        "alibi": "He claims he was preparing the dining room.",
        "statement": (
            "I locked the front entrance before the storm. "
            "No one could have left unnoticed."
        ),
    },
}

# The case solution is kept separate from the player-facing clues.
# We will use this later for the final deduction stage.
CASE_SOLUTION = {
    "culprit": "iris",
    "reason": "Story solution for the prototype; deduction gameplay is not yet implemented.",
}