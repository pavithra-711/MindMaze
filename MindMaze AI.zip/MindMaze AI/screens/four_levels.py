
import math
import json
import os
import random
from array import array
import pygame

pygame.init()

# --------------------------------------------------
# MIND MAZE AI - FOUR LEVELS
# Python 3.11 | Pygame
# --------------------------------------------------

WIDTH, HEIGHT = 1100, 720
FPS = 60

# Theme
BG = (9, 14, 29)
PANEL = (19, 28, 49)
PANEL_LIGHT = (27, 39, 65)
PURPLE = (153, 91, 255)
CYAN = (45, 224, 238)
GOLD = (255, 195, 76)
WHITE = (240, 245, 255)
MUTED = (153, 168, 194)
GREEN = (74, 222, 128)
RED = (255, 100, 125)
BORDER = (47, 62, 91)

screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Mind Maze AI | Detective Terminal")
clock = pygame.time.Clock()

FONT = pygame.font.SysFont("segoeui", 18)
SMALL = pygame.font.SysFont("segoeui", 14)
MEDIUM = pygame.font.SysFont("segoeui", 23, bold=True)
BIG = pygame.font.SysFont("segoeui", 36, bold=True)
TITLE = pygame.font.SysFont("segoeui", 43, bold=True)

# --------------------------------------------------
# GAME DATA
# --------------------------------------------------

LEVEL_NAMES = [
    "The Four Keys",
    "The Jumbled Message",
    "The Secret Door",
    "The Password Vault",
    "Detective Aptitude Test",
    "Final Murder Mystery",
]

CLUES = [
    {
        "name": "Broken Watch",
        "description": "The watch stopped at 10:15 PM.",
        "detail": "The victim's watch stopped at 10:15 PM. "
                  "This gives us a possible time of the attack.",
    },
    {
        "name": "Wine Glass",
        "description": "A glass contains unusual residue.",
        "detail": "The glass contains traces of a strange "
                  "substance. The laboratory must identify it.",
    },
    {
        "name": "Torn Note",
        "description": "A message mentions the secret lab.",
        "detail": "The note reads: 'Meet me below the east wing.'",
    },
    {
        "name": "Muddy Footprint",
        "description": "A muddy print leads toward the east wing.",
        "detail": "The footprint appears to lead toward the "
                  "restricted laboratory entrance.",
    },
]

SCENE_EXAMS = [
    ("CHECK WATCH GEARS", "Record the stopped time before handling the watch."),
    ("SWAB THE GLASS RIM", "Collect the residue for laboratory analysis."),
    ("REVEAL WRITING", "Use angled light to recover the pressed writing."),
    ("CAST SHOEPRINT", "Lift the tread pattern and preserve its direction."),
]

WORD_PUZZLES = [
    ("FENIK", "KNIFE", "A sharp object found missing from the kitchen."),
    ("BAILI", "ALIBI", "A suspect's account of where they were."),
    ("TCWAH", "WATCH", "The victim's stopped timepiece."),
    ("TLUAV", "VAULT", "Where the mansion hides its classified records."),
]
JUMBLE_ROUND_SECONDS = 30

KEY_LOCATIONS = [
    ((175, 185), "FOYER"),
    ((630, 185), "GALLERY"),
    ((620, 535), "SUN ROOM"),
    ((310, 535), "STUDY"),
]

SECRET_SYMBOLS = ["MOON", "EYE", "KEY"]
SECRET_DOOR_ANSWERS = {
    "MOON": "Look above the portrait: the moon is drawn first.",
    "EYE": "The mirror inscription places the eye beneath the moon.",
    "KEY": "The key is the final mark on the floor plan.",
}

FINAL_LOCATIONS = [
    "Secret laboratory",
    "Vale's study",
    "West library",
    "Conservatory",
]

FINAL_CASE_CLUES = [
    {
        "name": "Broken Watch",
        "detail": "The crystal is cracked and the hands stopped at 10:15 PM.",
        "color": GOLD,
        "position": (180, 205),
    },
    {
        "name": "Security Terminal",
        "detail": "The east-wing access log was manually disabled at 10:05 PM.",
        "color": CYAN,
        "position": (630, 190),
    },
    {
        "name": "Muddy Footprints",
        "detail": "Fresh prints lead from the courtyard into the secret laboratory.",
        "color": (174, 125, 82),
        "position": (180, 500),
    },
    {
        "name": "Chemical Container",
        "detail": "A rare sedative residue matches the victim's glass and the lab stores.",
        "color": PURPLE,
        "position": (620, 500),
    },
    {
        "name": "Desk Drawer",
        "detail": "A duplicate override key receipt bears Victor Shaw's initials.",
        "color": GREEN,
        "position": (390, 190),
    },
    {
        "name": "Hidden Passage",
        "detail": "A concealed route connects the east corridor directly to the secret laboratory.",
        "color": (255, 120, 193),
        "position": (420, 500),
    },
]

FINAL_SUSPECT_PROFILES = [
    {
        "name": "Dr. Evelyn Reed",
        "biography": "Research partner; co-authored Vale's early medical work.",
        "motive": "Vale planned to publish without crediting her.",
        "alibi": "Claims she stayed in the west library from 10:00 PM.",
        "statement": "I heard the storm from the library. I never went near the east wing.",
        "comparison_clues": [2],
        "comparison": "The muddy prints lead into the east wing, but do not place Evelyn in the lab during the attack.",
    },
    {
        "name": "Marcus Vale",
        "biography": "The victim's brother and executor of the family estate.",
        "motive": "A recent inheritance dispute over the mansion.",
        "alibi": "Claims he was on a call in the front hall at 10:00 PM.",
        "statement": "I saw Victor carrying a maintenance case toward the east corridor.",
        "comparison_clues": [4],
        "comparison": "The override-key receipt bears Victor's initials, supporting Marcus's report about the case.",
    },
    {
        "name": "Lena Hart",
        "biography": "Laboratory assistant who maintained the research archive.",
        "motive": "Feared dismissal after a laboratory inventory went missing.",
        "alibi": "Claims she left the laboratory before 9:00 PM.",
        "statement": "Victor had an override key. The passage behind the lab shelves was known to him.",
        "comparison_clues": [3, 5],
        "comparison": "The chemical residue and hidden route confirm Lena's lab details, but do not put her there at 10:15 PM.",
    },
    {
        "name": "Victor Shaw",
        "biography": "Head of mansion security with access to the override system.",
        "motive": "Vale discovered Victor was selling restricted research.",
        "alibi": "Claims he watched the front entrance continuously from 10:00 PM.",
        "statement": "The terminal must have failed in the storm. I never entered the laboratory.",
        "comparison_clues": [1, 4],
        "comparison": "The 10:05 manual override and receipt for a duplicate key contradict Victor's front-door alibi.",
    },
]

FINAL_TIMELINE_EVENTS = [
    {
        "id": "log",
        "time": "10:05 PM",
        "text": "Security log manually disabled",
        "reason": "Victor used the override before the murder and falsified the access trail.",
        "requires": 1,
    },
    {
        "id": "passage",
        "time": "10:10 PM",
        "text": "Footprints enter the hidden passage",
        "reason": "The muddy prints connect the courtyard route to the secret laboratory.",
        "requires": 2,
    },
    {
        "id": "attack",
        "time": "10:15 PM",
        "text": "Adrian Vale is attacked; his watch stops",
        "reason": "The broken watch fixes the attack after the terminal was disabled.",
        "requires": 0,
    },
    {
        "id": "escape",
        "time": "10:20 PM",
        "text": "Victor exits through the east corridor",
        "reason": "The concealed passage and override key gave Victor a route unseen by the front guard.",
        "requires": 5,
    },
]

APTITUDE_QUESTIONS = [
    {
        "category": "NUMBER SERIES",
        "question": "The watch log records 10:05, 10:10, 10:15. What comes next?",
        "choices": ["10:16", "10:20", "10:25", "11:15"],
        "answer": 1,
        "explanation": "The log advances in five-minute intervals.",
        "easy": "The sequence increases by five minutes each time.",
        "hard": "The five-minute interval places the victim's watch stop at 10:15.",
        "hard_question": "A second clock is 5 minutes slow. It shows 10:10 when the watch stopped. What was the actual time?",
        "hard_choices": ["10:05", "10:10", "10:15", "10:20"],
        "hard_answer": 2,
    },
    {
        "category": "LOGIC",
        "question": "Only the guard had the override key. The log was disabled with it. What follows?",
        "choices": ["The guard had access", "The guard is innocent", "The storm disabled it", "The log is reliable"],
        "answer": 0,
        "explanation": "The override key links the guard to access, but motive and opportunity still matter.",
        "easy": "Possessing the only override key establishes access, not automatically guilt.",
        "hard": "Access plus the 10:05 timestamp conflicts with the guard's front-door alibi.",
        "hard_question": "Only Victor has the override, and it is used at 10:05. His alibi begins at 10:00. What is contradicted?",
        "hard_choices": ["His location", "His motive", "The storm", "The watch"],
        "hard_answer": 0,
    },
    {
        "category": "DIRECTIONS",
        "question": "A muddy trail goes north from the courtyard, then east at the portrait hall. Where does it lead?",
        "choices": ["Kitchen", "East wing", "West gate", "Library"],
        "answer": 1,
        "explanation": "Following north and then east leads to the east wing.",
        "easy": "Follow the last direction in the trail: east.",
        "hard": "The footprint route ends at the restricted east-wing entrance.",
        "hard_question": "From the courtyard go north, east, then east again. Which wing is reached?",
        "hard_choices": ["North tower", "East wing", "West library", "Cellar"],
        "hard_answer": 1,
    },
    {
        "category": "CODE BREAKING",
        "question": "Each letter is shifted one position forward: WBMF. Decode the name.",
        "choices": ["Marcus", "Vale", "Victor", "Evelyn"],
        "answer": 1,
        "explanation": "Shift each letter back once: W→V, B→A, M→L, F→E. The encoded name is VALE.",
        "easy": "Reverse the shift by moving each letter one position back.",
        "hard": "The one-step reverse cipher spells the victim's family name.",
        "hard_question": "Decode WBMF by shifting each letter back one place. What name is encoded?",
        "hard_choices": ["Marcus", "Vale", "Victor", "Evelyn"],
        "hard_answer": 1,
    },
    {
        "category": "ANALYSIS",
        "question": "The keycard opened the east wing at 10:05. The watch stopped at 10:15. What is the strongest conclusion?",
        "choices": ["Entry came before the attack", "The watch is unrelated", "The storm stopped the watch", "Nobody entered"],
        "answer": 0,
        "explanation": "The recorded entry precedes the watch stopping by ten minutes.",
        "easy": "Compare the two times: 10:05 comes before 10:15.",
        "hard": "The ten-minute window narrows the opportunity; match it against suspect alibis.",
        "hard_question": "A 10:05 access log and 10:15 stopped watch leave a 10-minute window. Which suspect can access the control room?",
        "hard_choices": ["Dr. Reed", "Marcus Vale", "Lena Hart", "Victor Shaw"],
        "hard_answer": 3,
    },
]

SUSPECTS = [
    {
        "name": "Dr. Evelyn Reed",
        "role": "Research Partner",
        "motive": "A disputed research discovery",
        "alibi": "I was in the library at 10 PM.",
        "question": "What were you researching?",
        "answer": "The victim planned to publish our research "
                  "without acknowledging my contribution.",
    },
    {
        "name": "Marcus Vale",
        "role": "Victim's Brother",
        "motive": "Inheritance dispute",
        "alibi": "I was in the west hall all evening.",
        "question": "Did you visit the east wing?",
        "answer": "I went near the east wing earlier, but "
                  "I never entered the laboratory.",
    },
    {
        "name": "Lena Hart",
        "role": "Laboratory Assistant",
        "motive": "A threatened dismissal",
        "alibi": "I left the laboratory before 9 PM.",
        "question": "Who could enter the laboratory?",
        "answer": "The victim and senior researchers had access. "
                  "The security log recorded a late entry.",
    },
    {
        "name": "Victor Shaw",
        "role": "Security Chief",
        "motive": "A concealed security breach",
        "alibi": "I was monitoring the front entrance.",
        "question": "What happened to the security log?",
        "answer": "The east-wing log was manually disabled at "
                  "10:05 PM using an administrator override.",
    },
]

# The story is fictional. Evidence and the solution are
# intentionally designed as part of this game's puzzle.
CORRECT_PASSWORD = "1005"
CORRECT_SUSPECT = "Victor Shaw"


# --------------------------------------------------
# HELPER FUNCTIONS
# --------------------------------------------------

def draw_text(surface, text, font, color, x, y):
    image = font.render(str(text), True, color)
    surface.blit(image, (x, y))
    return image.get_rect(topleft=(x, y))


def wrap_text(text, font, max_width):
    words = text.split()
    lines = []
    current = ""

    for word in words:
        test = f"{current} {word}".strip()

        if font.size(test)[0] <= max_width:
            current = test
        else:
            if current:
                lines.append(current)
            current = word

    if current:
        lines.append(current)

    return lines


def draw_paragraph(surface, text, font, color, x, y,
                   max_width, line_height=25):
    for line in wrap_text(text, font, max_width):
        draw_text(surface, line, font, color, x, y)
        y += line_height
    return y


def draw_panel(surface, rect, color=PANEL, border=BORDER):
    rect = pygame.Rect(rect)
    shadow = rect.move(0, 5)
    pygame.draw.rect(
        surface, (5, 9, 20), shadow, border_radius=15
    )
    pygame.draw.rect(surface, color, rect, border_radius=15)
    pygame.draw.rect(surface, border, rect, width=1, border_radius=15)
    pygame.draw.line(
        surface, (min(border[0] + 18, 255),
                  min(border[1] + 18, 255),
                  min(border[2] + 18, 255)),
        (rect.x + 16, rect.y + 1),
        (rect.right - 16, rect.y + 1),
        1,
    )


def draw_button(surface, rect, label, mouse_pos,
                accent=PURPLE, enabled=True):
    hovered = rect.collidepoint(mouse_pos) and enabled

    pygame.draw.rect(
        surface, (5, 9, 20), rect.move(0, 4), border_radius=10
    )

    if not enabled:
        fill = (35, 42, 59)
        outline = (54, 65, 85)
        text_color = MUTED
    elif hovered:
        fill = (46, 43, 86)
        outline = CYAN
        text_color = WHITE
    else:
        fill = PANEL_LIGHT
        outline = accent
        text_color = WHITE

    pygame.draw.rect(surface, fill, rect, border_radius=10)
    pygame.draw.rect(surface, outline, rect, 2, border_radius=10)
    if enabled:
        pygame.draw.line(
            surface,
            tuple(min(channel + 28, 255) for channel in accent),
            (rect.x + 12, rect.y + 2),
            (rect.right - 12, rect.y + 2),
            1,
        )

    label_image = FONT.render(label, True, text_color)
    label_rect = label_image.get_rect(center=rect.center)
    surface.blit(label_image, label_rect)


def draw_background(surface, ticks):
    surface.fill(BG)

    # Keep the backdrop quiet so the evidence panels remain the focus.
    for y in range(100, HEIGHT, 52):
        pygame.draw.line(surface, (13, 21, 39), (0, y), (WIDTH, y), 1)

    for x in range(35, WIDTH, 72):
        pygame.draw.line(surface, (12, 19, 36), (x, 95), (x, HEIGHT), 1)

    # Animated decorative neon circles
    for i in range(5):
        x = 90 + i * 245
        y = 105 + int(math.sin(ticks / 850 + i) * 12)
        pygame.draw.circle(surface, (19, 27, 51), (x, y), 42)
        pygame.draw.circle(surface, (29, 40, 70), (x, y), 42, 1)

    for i in range(18):
        x = (i * 137 + int(ticks / (35 + i % 4))) % WIDTH
        y = 115 + (i * 83 % (HEIGHT - 140))
        pulse = int(35 + 30 * abs(math.sin(ticks / 700 + i)))
        pygame.draw.circle(surface, (pulse, pulse + 8, pulse + 22), (x, y), 1)

    pygame.draw.line(surface, (32, 46, 73),
                     (0, 90), (WIDTH, 90), 1)


# --------------------------------------------------
# GAME STATE
# --------------------------------------------------

class MindMazeGame:
    def __init__(self):
        self.level = 0
        self.score = 0
        self.unlocked_level = 0

        self.collected_clues = set()
        self.inspected_clues = set()
        self.photographed_clues = set()
        self.selected_clue = None
        self.asked_suspects = set()
        self.revealed_contradiction = False
        self.player = pygame.Rect(112, 535, 24, 30)
        self.player_speed = 220
        self.keys_collected = set()
        self.jumble_index = 0
        self.jumble_answer = ""
        self.jumble_solved = set()
        self.jumble_streak = 0
        self.jumble_scramble = ""
        self.jumble_started_at = pygame.time.get_ticks()
        self.secret_symbols_found = set()
        self.secret_door_code = []
        self.secret_compartment_open = False
        self.secret_key_found = False
        self.secret_door_unlocked = False
        self.flashlight_on = False
        self.flashlight_energy = 100
        self.flashlight_last_tick = pygame.time.get_ticks()
        self.vault_failures = 0
        self.vault_locked_until = 0
        self.quiz_index = 0
        self.quiz_score = 0
        self.quiz_streak = 0
        self.quiz_completed = False
        self.quiz_show_answer = False
        self.quiz_last_correct = False
        self.quiz_last_explanation = ""
        self.quiz_selected = None
        self.final_suspect = None
        self.final_location = None
        self.final_evidence_presented = set()
        self.final_case_solved = False
        self.final_best_ending = False
        self.final_case_stage = "discovery"
        self.body_discovered = False
        self.final_clues_found = set()
        self.final_suspects_interviewed = set()
        self.final_active_suspect = None
        self.final_timeline_order = []
        self.final_timeline_complete = False
        self.final_timeline_awarded = False
        self.final_timeline_feedback = ""
        self.final_case_ending = None
        self.jumble_time_left = JUMBLE_ROUND_SECONDS
        self.jumble_last_tick = pygame.time.get_ticks()
        self.mansion_key_found = False
        self.hidden_ledger_found = False
        self.mansion_door_unlocked = False
        self.confrontation_complete = False
        self.paused = False
        self.tutorial_open = True
        self.tutorial_seen = False

        self.password = ""
        self.password_solved = False
        self.accusation = None
        self.ending = None

        self.message = "Begin your investigation, Detective."
        self.message_color = CYAN

        self.hints_used = 0
        self.notebook_open = False
        self.running = True
        self.dialogue_open = False
        self.dialogue_close_rect = pygame.Rect(800, 520, 120, 42)

        self.buttons = []
        self.active_suspect = None
        self.save_path = os.path.join(
            os.path.dirname(os.path.abspath(__file__)),
            "mind_maze_save.json",
        )
        self.load_progress()
        self.ensure_jumble_scramble()

    def ensure_jumble_scramble(self):
        if self.jumble_index >= len(WORD_PUZZLES):
            self.jumble_scramble = ""
            return
        solution = WORD_PUZZLES[self.jumble_index][1]
        if (
            len(self.jumble_scramble) != len(solution)
            or sorted(self.jumble_scramble) != sorted(solution)
            or self.jumble_scramble == solution
        ):
            letters = list(solution)
            random.shuffle(letters)
            if "".join(letters) == solution:
                letters = letters[1:] + letters[:1]
            self.jumble_scramble = "".join(letters)

    def notify(self, message, color=CYAN):
        self.message = message
        self.message_color = color

    def reset_buttons(self):
        self.buttons = []

    def add_button(self, rect, label, action,
                   accent=PURPLE, enabled=True):
        self.buttons.append({
            "rect": pygame.Rect(rect),
            "label": label,
            "action": action,
            "accent": accent,
            "enabled": enabled,
        })

    def complete_level(self, next_level):
        self.unlocked_level = max(
            self.unlocked_level,
            min(next_level, 5)
        )

    def save_progress(self):
        data = {
            "level": self.level,
            "unlocked_level": self.unlocked_level,
            "score": self.score,
            "collected_clues": sorted(self.collected_clues),
            "inspected_clues": sorted(self.inspected_clues),
            "photographed_clues": sorted(self.photographed_clues),
            "asked_suspects": sorted(self.asked_suspects),
            "revealed_contradiction": self.revealed_contradiction,
            "password_solved": self.password_solved,
            "password_code_version": 2,
            "mansion_key_found": self.mansion_key_found,
            "hidden_ledger_found": self.hidden_ledger_found,
            "mansion_door_unlocked": self.mansion_door_unlocked,
            "final_evidence_presented": sorted(self.final_evidence_presented),
            "confrontation_complete": self.confrontation_complete,
            "ending": self.ending,
            "tutorial_seen": self.tutorial_seen,
            "game_version": 6,
            "keys_collected": sorted(self.keys_collected),
            "jumble_index": self.jumble_index,
            "jumble_answer": self.jumble_answer,
            "jumble_scramble": self.jumble_scramble,
            "jumble_solved": sorted(self.jumble_solved),
            "jumble_streak": self.jumble_streak,
            "secret_symbols_found": sorted(self.secret_symbols_found),
            "secret_door_code": self.secret_door_code,
            "secret_compartment_open": self.secret_compartment_open,
            "secret_key_found": self.secret_key_found,
            "secret_door_unlocked": self.secret_door_unlocked,
            "flashlight_energy": self.flashlight_energy,
            "vault_failures": self.vault_failures,
            "quiz_index": self.quiz_index,
            "quiz_score": self.quiz_score,
            "quiz_streak": self.quiz_streak,
            "quiz_completed": self.quiz_completed,
            "quiz_show_answer": self.quiz_show_answer,
            "quiz_last_correct": self.quiz_last_correct,
            "quiz_last_explanation": self.quiz_last_explanation,
            "quiz_selected": self.quiz_selected,
            "final_suspect": self.final_suspect,
            "final_location": self.final_location,
            "final_evidence_presented": sorted(self.final_evidence_presented),
            "final_case_solved": self.final_case_solved,
            "final_best_ending": self.final_best_ending,
            "final_case_stage": self.final_case_stage,
            "body_discovered": self.body_discovered,
            "final_clues_found": sorted(self.final_clues_found),
            "final_suspects_interviewed": sorted(self.final_suspects_interviewed),
            "final_active_suspect": self.final_active_suspect,
            "final_timeline_order": self.final_timeline_order,
            "final_timeline_complete": self.final_timeline_complete,
            "final_timeline_awarded": self.final_timeline_awarded,
            "final_timeline_feedback": self.final_timeline_feedback,
            "final_case_ending": self.final_case_ending,
            "jumble_time_left": self.jumble_time_left,
            "vault_lockout_seconds": max(
                0, int((self.vault_locked_until - pygame.time.get_ticks()) / 1000)
            ),
        }
        try:
            with open(self.save_path, "w", encoding="utf-8") as save_file:
                json.dump(data, save_file, indent=2)
        except OSError as error:
            print(f"Could not save Mind Maze progress: {error}")

    def load_progress(self):
        try:
            with open(self.save_path, encoding="utf-8") as save_file:
                data = json.load(save_file)
        except FileNotFoundError:
            return
        except (OSError, json.JSONDecodeError) as error:
            print(f"Could not load Mind Maze progress: {error}")
            return

        if data.get("game_version") not in (5, 6):
            print("Starting the detective case with a fresh save.")
            return
        save_version = data.get("game_version")

        try:
            self.level = max(0, min(int(data.get("level", 0)), 5))
            self.unlocked_level = max(
                self.level,
                min(int(data.get("unlocked_level", self.level)), 5),
            )
            self.score = max(0, int(data.get("score", 0)))
            self.collected_clues = set(data.get("collected_clues", []))
            self.inspected_clues = set(data.get("inspected_clues", []))
            self.photographed_clues = set(data.get("photographed_clues", []))
            self.asked_suspects = set(data.get("asked_suspects", []))
            self.revealed_contradiction = bool(
                data.get("revealed_contradiction", False)
            )
            self.password_solved = (
                bool(data.get("password_solved", False))
                and data.get("password_code_version") == 2
            )
            self.mansion_key_found = bool(data.get("mansion_key_found", False))
            self.hidden_ledger_found = bool(
                data.get("hidden_ledger_found", False)
            )
            self.mansion_door_unlocked = bool(
                data.get("mansion_door_unlocked", False)
            )
            self.final_evidence_presented = set(
                data.get("final_evidence_presented", [])
            )
            self.confrontation_complete = bool(
                data.get("confrontation_complete", False)
            )
            self.tutorial_seen = bool(data.get("tutorial_seen", False))
            self.tutorial_open = not self.tutorial_seen
            self.keys_collected = set(data.get("keys_collected", []))
            self.jumble_index = max(
                0, min(int(data.get("jumble_index", 0)), len(WORD_PUZZLES))
            )
            self.jumble_answer = str(data.get("jumble_answer", ""))[:12]
            self.jumble_scramble = str(data.get("jumble_scramble", ""))[:12]
            self.jumble_solved = set(data.get("jumble_solved", []))
            self.jumble_streak = max(0, int(data.get("jumble_streak", 0)))
            self.jumble_time_left = max(
                0,
                min(
                    int(data.get("jumble_time_left", JUMBLE_ROUND_SECONDS)),
                    JUMBLE_ROUND_SECONDS,
                ),
            )
            self.jumble_last_tick = pygame.time.get_ticks()
            self.secret_symbols_found = set(data.get("secret_symbols_found", []))
            self.secret_door_code = list(data.get("secret_door_code", []))[:3]
            self.secret_compartment_open = bool(
                data.get("secret_compartment_open", False)
            )
            self.secret_key_found = bool(data.get("secret_key_found", False))
            self.secret_door_unlocked = bool(
                data.get("secret_door_unlocked", False)
            )
            self.flashlight_energy = max(
                0, min(int(data.get("flashlight_energy", 100)), 100)
            )
            self.vault_failures = max(0, int(data.get("vault_failures", 0)))
            self.vault_locked_until = (
                pygame.time.get_ticks()
                + max(0, int(data.get("vault_lockout_seconds", 0))) * 1000
            )
            self.quiz_index = max(
                0, min(int(data.get("quiz_index", 0)), len(APTITUDE_QUESTIONS))
            )
            self.quiz_score = max(0, int(data.get("quiz_score", 0)))
            self.quiz_streak = max(0, int(data.get("quiz_streak", 0)))
            self.quiz_completed = bool(data.get("quiz_completed", False))
            self.quiz_show_answer = bool(data.get("quiz_show_answer", False))
            self.quiz_last_correct = bool(data.get("quiz_last_correct", False))
            self.quiz_last_explanation = str(
                data.get("quiz_last_explanation", "")
            )[:300]
            selected = data.get("quiz_selected")
            self.quiz_selected = (
                int(selected) if selected is not None and 0 <= int(selected) < 4
                else None
            )
            self.final_suspect = data.get("final_suspect")
            if self.final_suspect not in {
                suspect["name"] for suspect in FINAL_SUSPECT_PROFILES
            }:
                self.final_suspect = None
            self.final_location = data.get("final_location")
            if self.final_location not in FINAL_LOCATIONS:
                self.final_location = None
            self.final_evidence_presented = {
                int(index) for index in data.get("final_evidence_presented", [])
                if str(index).isdigit()
                and 0 <= int(index) < len(FINAL_CASE_CLUES)
            }
            self.final_case_solved = bool(data.get("final_case_solved", False))
            self.final_best_ending = bool(data.get("final_best_ending", False))
            stage = data.get("final_case_stage", "discovery")
            self.final_case_stage = (
                stage if stage in {
                    "discovery", "discovery_dialogue", "evidence",
                    "interviews", "timeline", "accusation", "ending",
                } else "discovery"
            )
            self.body_discovered = bool(data.get("body_discovered", False))
            self.final_clues_found = {
                int(index) for index in data.get("final_clues_found", [])
                if str(index).isdigit()
                and 0 <= int(index) < len(FINAL_CASE_CLUES)
            }
            self.final_suspects_interviewed = {
                int(index) for index in data.get("final_suspects_interviewed", [])
                if str(index).isdigit()
                and 0 <= int(index) < len(FINAL_SUSPECT_PROFILES)
            }
            active_suspect = data.get("final_active_suspect")
            self.final_active_suspect = (
                int(active_suspect)
                if active_suspect is not None
                and str(active_suspect).isdigit()
                and 0 <= int(active_suspect) < len(FINAL_SUSPECT_PROFILES)
                else None
            )
            self.final_timeline_order = [
                event_id for event_id in data.get("final_timeline_order", [])
                if event_id in {event["id"] for event in FINAL_TIMELINE_EVENTS}
            ][:len(FINAL_TIMELINE_EVENTS)]
            self.final_timeline_complete = bool(
                data.get("final_timeline_complete", False)
            )
            self.final_timeline_awarded = bool(
                data.get("final_timeline_awarded", False)
            )
            self.final_timeline_feedback = str(
                data.get("final_timeline_feedback", "")
            )[:250]
            case_ending = data.get("final_case_ending")
            self.final_case_ending = (
                case_ending if case_ending in {"master", "solved", "wrong"}
                else None
            )
            ending = data.get("ending")
            if ending in {"perfect", "correct", "wrong", "wrong_evelyn"}:
                self.ending = ending
            if save_version == 5:
                self.final_suspect = None
                self.final_location = None
                self.final_evidence_presented.clear()
                self.final_case_solved = False
                self.final_best_ending = False
                self.final_case_stage = "discovery"
                self.final_case_ending = None
        except (TypeError, ValueError) as error:
            print(f"Mind Maze save data is invalid: {error}")

    def use_hint(self):
        self.hints_used += 1

        if self.level == 0:
            self.notify(
                "Hint: Find one glowing key in each colored room. Move beside it and press E.",
                GOLD
            )
        elif self.level == 1:
            self.notify(
                f"Hint: {WORD_PUZZLES[self.jumble_index][2] if self.jumble_index < len(WORD_PUZZLES) else 'The door is behind the moon portrait.'}",
                GOLD
            )
        elif self.level == 2:
            self.notify(
                "Hint: F reveals the three symbols. Enter MOON → EYE → KEY to open a hidden key compartment. Take its key, then test the three doors.",
                GOLD
            )
        elif self.level == 3:
            self.notify(
                "Hint: The security log was disabled at 10:05 PM. Enter that time as four digits.",
                GOLD
            )
        elif self.level == 4:
            self.notify(
                "Hint: Compare the security log, suspect access, footprint direction, and stopped watch.",
                GOLD
            )
        else:
            hints = {
                "discovery": "Search the east wing. Move beside Dr. Vale and press E.",
                "discovery_dialogue": "Secure the scene to begin collecting the six glowing clues.",
                "evidence": "Walk near each numbered clue marker and press E to secure it.",
                "interviews": "Open each suspect card, read all four parts, then record the interview.",
                "timeline": "Start with the 10:05 log, then the passage, 10:15 attack, and escape.",
                "accusation": "The terminal log plus drawer, chemical, or passage evidence supports Victor in the secret laboratory.",
            }
            self.notify(
                hints.get(self.final_case_stage, "Review the detective notebook."),
                GOLD,
            )

    # --------------------------------------------------
    # SHARED HEADER AND FOOTER
    # --------------------------------------------------

    def draw_header(self, mouse_pos, ticks):
        draw_background(screen, ticks)

        # Brand
        pygame.draw.rect(
            screen, PURPLE,
            (25, 22, 45, 45), border_radius=12
        )
        draw_text(screen, "M", BIG, WHITE, 35, 23)

        draw_text(screen, "MIND MAZE AI", MEDIUM, WHITE, 82, 22)
        draw_text(
            screen, "THE ADRIAN VALE CASE",
            SMALL, MUTED, 83, 51
        )

        # Score and level
        draw_panel(screen, (765, 24, 135, 43))
        draw_text(
            screen, f"SCORE  {self.score}",
            FONT, GOLD, 780, 34
        )

        draw_panel(screen, (912, 24, 160, 43))
        draw_text(
            screen, f"LEVEL  {self.level + 1} / 6",
            FONT, CYAN, 927, 34
        )

        # Progress
        bar_rect = pygame.Rect(25, 81, 1047, 4)
        pygame.draw.rect(screen, BORDER, bar_rect, border_radius=3)

        progress = (self.unlocked_level + 1) / 6
        pygame.draw.rect(
            screen, PURPLE,
            (25, 81, int(1047 * progress), 4),
            border_radius=3
        )

        for index in range(6):
            x = 25 + int(1047 * index / 5)
            reached = index <= self.unlocked_level
            color = CYAN if reached else BORDER
            pygame.draw.circle(screen, (9, 14, 29), (x, 83), 7)
            pygame.draw.circle(screen, color, (x, 83), 5)
            pygame.draw.circle(screen, WHITE if reached else BORDER, (x, 83), 2)

    def draw_footer(self):
        pygame.draw.line(
            screen, BORDER, (25, 663), (1075, 663), 1
        )

        draw_text(
            screen, self.message, SMALL,
            self.message_color, 28, 678
        )

        hint_rect = pygame.Rect(735, 674, 140, 30)
        draw_button(
            screen, hint_rect, "H  /  HINT",
            pygame.mouse.get_pos(), GOLD
        )
        self.add_button(hint_rect, "HINT", "hint", GOLD)

        notebook_rect = pygame.Rect(890, 674, 180, 30)
        draw_button(
            screen, notebook_rect,
            "DETECTIVE NOTEBOOK",
            pygame.mouse.get_pos(), CYAN
        )

        self.add_button(
            notebook_rect, "DETECTIVE NOTEBOOK",
            "notebook", CYAN
        )

    # --------------------------------------------------
    # LEVEL 1 - CRIME SCENE
    # --------------------------------------------------

    def move_player(self, dt, bounds, obstacles):
        keys = pygame.key.get_pressed()
        direction = pygame.Vector2(
            int(keys[pygame.K_d] or keys[pygame.K_RIGHT])
            - int(keys[pygame.K_a] or keys[pygame.K_LEFT]),
            int(keys[pygame.K_s] or keys[pygame.K_DOWN])
            - int(keys[pygame.K_w] or keys[pygame.K_UP]),
        )
        if not direction.length_squared():
            return
        direction = direction.normalize()
        distance = self.player_speed * dt

        self.player.x += round(direction.x * distance)
        self.player.clamp_ip(bounds)
        if any(self.player.colliderect(obstacle) for obstacle in obstacles):
            self.player.x -= round(direction.x * distance)

        self.player.y += round(direction.y * distance)
        self.player.clamp_ip(bounds)
        if any(self.player.colliderect(obstacle) for obstacle in obstacles):
            self.player.y -= round(direction.y * distance)

    def draw_player(self):
        pygame.draw.ellipse(
            screen, (6, 10, 20),
            (self.player.x - 3, self.player.bottom - 3, 30, 9)
        )
        pygame.draw.rect(
            screen, (50, 53, 102), self.player, border_radius=8
        )
        pygame.draw.rect(
            screen, CYAN, self.player, 2, border_radius=8
        )
        pygame.draw.circle(
            screen, (255, 213, 177),
            (self.player.centerx, self.player.y + 7), 7
        )
        pygame.draw.line(
            screen, GOLD,
            (self.player.centerx, self.player.y + 16),
            (self.player.centerx, self.player.bottom - 4), 3
        )

    def draw_world_sidebar(self, title, lines, objective, progress):
        panel = pygame.Rect(856, 112, 218, 535)
        draw_panel(screen, panel, (23, 35, 59), (79, 103, 148))
        draw_text(screen, title, MEDIUM, WHITE, panel.x + 17, panel.y + 19)
        draw_text(screen, "YOUR NEXT TASK", SMALL, GOLD, panel.x + 17, panel.y + 64)
        draw_paragraph(
            screen, objective, FONT, WHITE,
            panel.x + 17, panel.y + 88, panel.width - 34, 21
        )
        y = panel.y + 160
        for color, text in lines:
            pygame.draw.circle(screen, color, (panel.x + 23, y + 8), 5)
            y = draw_paragraph(
                screen, text, SMALL, (222, 231, 247),
                panel.x + 36, y, panel.width - 51, 19
            ) + 11
        pygame.draw.line(
            screen, BORDER,
            (panel.x + 17, panel.bottom - 62),
            (panel.right - 17, panel.bottom - 62), 1
        )
        draw_text(
            screen, progress, SMALL, GOLD,
            panel.x + 17, panel.bottom - 65
        )
        draw_text(
            screen, "WASD / arrows  MOVE", SMALL, CYAN,
            panel.x + 17, panel.bottom - 45
        )
        draw_text(
            screen, "E: interact   H: hint   P: pause", SMALL, WHITE,
            panel.x + 17, panel.bottom - 25
        )
        draw_text(
            screen, "F1: show this guide", SMALL, GOLD,
            panel.x + 17, panel.bottom - 82
        )

    def nearest_scene_clue(self):
        targets = [
            pygame.Vector2(400, 333),
            pygame.Vector2(510, 326),
            pygame.Vector2(622, 333),
            pygame.Vector2(177, 505),
        ]
        nearest = min(
            range(len(targets)),
            key=lambda index: pygame.Vector2(self.player.center).distance_to(
                targets[index]
            ),
        )
        distance = pygame.Vector2(self.player.center).distance_to(targets[nearest])
        return nearest if distance <= 82 else None

    def interact_scene(self):
        clue_index = self.nearest_scene_clue()
        if clue_index is None:
            self.notify("Move closer to an evidence marker to inspect it.", GOLD)
            return
        if clue_index in self.collected_clues:
            self.notify("This evidence is already secured.", GOLD)
            return
        self.selected_clue = clue_index
        self.notify(
            f"Evidence located: {CLUES[clue_index]['name']}. Complete the field protocol.",
            CYAN
        )

    def draw_playable_scene(self, mouse_pos, dt):
        room = pygame.Rect(35, 108, 800, 542)
        pygame.draw.rect(screen, (24, 29, 49), room, border_radius=14)
        pygame.draw.rect(screen, (82, 53, 70), (45, 380, 780, 260), border_radius=8)
        for x in range(58, 825, 48):
            pygame.draw.line(screen, (99, 65, 69), (x, 386), (x - 35, 638), 1)

        # Rain-streaked window and the furniture that constrains movement.
        pygame.draw.rect(screen, (18, 39, 67), (76, 148, 190, 132), border_radius=8)
        pygame.draw.rect(screen, CYAN, (76, 148, 190, 132), 2, border_radius=8)
        pygame.draw.line(screen, CYAN, (171, 150), (171, 278), 2)
        pygame.draw.line(screen, CYAN, (78, 214), (264, 214), 2)
        for x in range(91, 250, 25):
            pygame.draw.line(screen, (60, 106, 148), (x, 158), (x - 12, 188), 1)

        obstacles = [
            pygame.Rect(76, 302, 156, 48),
            pygame.Rect(267, 377, 230, 54),
            pygame.Rect(267, 431, 17, 104),
            pygame.Rect(480, 431, 17, 104),
            pygame.Rect(667, 160, 112, 40),
            pygame.Rect(700, 426, 92, 82),
        ]
        pygame.draw.rect(screen, (80, 57, 65), obstacles[0], border_radius=12)
        pygame.draw.rect(screen, (47, 39, 56), obstacles[0].inflate(-16, -12), border_radius=9)
        pygame.draw.rect(screen, (105, 72, 61), obstacles[1], border_radius=6)
        pygame.draw.rect(screen, (51, 40, 48), obstacles[2], border_radius=3)
        pygame.draw.rect(screen, (51, 40, 48), obstacles[3], border_radius=3)
        pygame.draw.rect(screen, (79, 64, 54), obstacles[4], border_radius=6)
        pygame.draw.rect(screen, (59, 43, 60), obstacles[5], border_radius=8)

        clue_points = [(400, 333), (510, 326), (622, 333), (177, 505)]
        clue_colors = [GOLD, CYAN, PURPLE, (190, 131, 87)]
        clue_labels = ["WATCH", "GLASS", "NOTE", "PRINT"]
        ticks = pygame.time.get_ticks()
        for index, point in enumerate(clue_points):
            if index in self.collected_clues:
                color = GREEN
                label = "SECURED"
            elif index in self.inspected_clues:
                color = GOLD
                label = clue_labels[index]
            else:
                color = clue_colors[index]
                label = clue_labels[index]
            radius = 15 + int(2 * abs(math.sin(ticks / 350 + index)))
            pygame.draw.circle(screen, (12, 18, 31), point, radius + 7)
            pygame.draw.circle(screen, color, point, radius, 2)
            pygame.draw.circle(screen, color, point, 4)
            label_surface = SMALL.render(label, True, color)
            screen.blit(label_surface, label_surface.get_rect(center=(point[0], point[1] + 26)))

        if (
            self.selected_clue is None
            and not self.notebook_open
            and not self.tutorial_open
            and not self.paused
        ):
            self.move_player(dt, room.inflate(-18, -18), obstacles)
        self.draw_player()
        nearby = self.nearest_scene_clue()
        if nearby is not None and nearby not in self.collected_clues:
            prompt_rect = pygame.Rect(267, 584, 348, 34)
            pygame.draw.rect(screen, (8, 14, 27), prompt_rect, border_radius=8)
            pygame.draw.rect(screen, CYAN, prompt_rect, 1, border_radius=8)
            prompt = FONT.render(
                f"Press E to investigate {clue_labels[nearby]}",
                True, WHITE
            )
            screen.blit(prompt, prompt.get_rect(center=prompt_rect.center))

        remaining = 4 - len(self.collected_clues)
        scene_objective = (
            "Evidence window open: click the bright buttons in order — cyan, purple, green."
            if self.selected_clue is not None
            else "Walk next to a glowing clue and press E. Or click the clue directly."
        )
        self.draw_world_sidebar(
            "Crime Scene",
            [
                (GOLD, f"Inspect: {len(self.inspected_clues)} / 4"),
                (PURPLE, f"Photograph: {len(self.photographed_clues)} / 4"),
                (GREEN, f"Bag evidence: {len(self.collected_clues)} / 4"),
                (CYAN, "Four clues: watch, glass, note, shoeprint."),
            ],
            scene_objective if remaining else "All four clues secured. Click LEAVE THE SCENE to continue.",
            f"SCENE SECURED  {len(self.collected_clues)}/4",
        )

        if self.selected_clue is not None:
            self.draw_evidence_dialogue(mouse_pos)

        if len(self.collected_clues) == 4:
            finish_rect = pygame.Rect(862, 588, 205, 42)
            draw_button(screen, finish_rect, "LEAVE THE SCENE  →", mouse_pos, GREEN)
            self.add_button(finish_rect, "LEAVE SCENE", "finish1", GREEN)

    def draw_four_keys(self, mouse_pos, dt):
        room = pygame.Rect(35, 108, 800, 542)
        pygame.draw.rect(screen, (21, 34, 56), room, border_radius=15)
        pygame.draw.rect(screen, (67, 94, 130), room, 2, border_radius=15)

        room_colors = [(83, 49, 67), (38, 72, 88), (75, 60, 42), (52, 48, 88)]
        for index, color in enumerate(room_colors):
            x = 50 + index * 194
            pygame.draw.rect(
                screen, color, (x, 124, 180, 506), border_radius=12
            )
            pygame.draw.rect(
                screen, tuple(min(channel + 24, 255) for channel in color),
                (x, 124, 180, 506), 2, border_radius=12
            )
            name = ("FOYER", "GALLERY", "SUN ROOM", "STUDY")[index]
            draw_text(screen, name, SMALL, WHITE, x + 15, 139)
            for floor_y in range(410, 620, 38):
                pygame.draw.line(
                    screen, (21, 28, 46),
                    (x + 8, floor_y), (x + 172, floor_y), 1
                )

        obstacles = [
            pygame.Rect(88, 262, 98, 35),
            pygame.Rect(255, 322, 130, 38),
            pygame.Rect(442, 248, 116, 42),
            pygame.Rect(617, 340, 106, 42),
            pygame.Rect(700, 160, 62, 100),
        ]
        for index, obstacle in enumerate(obstacles):
            pygame.draw.rect(
                screen, (97, 72 + index * 3, 64), obstacle,
                border_radius=7
            )
            pygame.draw.rect(
                screen, GOLD, obstacle, 1, border_radius=7
            )

        # Open arches connect the four rooms.
        for x in (230, 424, 618):
            pygame.draw.rect(screen, (18, 24, 40), (x, 350, 18, 110))
            pygame.draw.line(screen, GOLD, (x, 350), (x + 18, 350), 3)

        ticks = pygame.time.get_ticks()
        for index, (position, room_name) in enumerate(KEY_LOCATIONS):
            x, y = position
            if index in self.keys_collected:
                draw_text(screen, "KEY FOUND", SMALL, GREEN, x - 32, y + 25)
                continue
            pulse = int(2 * abs(math.sin(ticks / 240 + index)))
            pygame.draw.circle(screen, (27, 24, 47), position, 23 + pulse)
            pygame.draw.circle(screen, GOLD, position, 15 + pulse, 3)
            pygame.draw.circle(screen, (255, 228, 129), position, 5)
            pygame.draw.circle(screen, GOLD, (x + 10, y), 4)
            draw_text(screen, f"KEY {index + 1}", SMALL, GOLD, x - 32, y + 25)

        bounds = pygame.Rect(44, 117, 782, 524)
        if not self.tutorial_open and not self.paused and not self.notebook_open:
            self.move_player(dt, bounds, obstacles)
        self.draw_player()

        key = self.nearby_key()
        if key is not None:
            prompt_rect = pygame.Rect(250, 580, 370, 38)
            pygame.draw.rect(screen, (8, 14, 27), prompt_rect, border_radius=8)
            pygame.draw.rect(screen, GOLD, prompt_rect, 2, border_radius=8)
            prompt = FONT.render(
                f"PRESS E TO COLLECT KEY {key + 1}", True, WHITE
            )
            screen.blit(prompt, prompt.get_rect(center=prompt_rect.center))

        left = len(KEY_LOCATIONS) - len(self.keys_collected)
        self.draw_world_sidebar(
            "THE FOUR KEYS",
            [
                (GOLD, f"Keys found: {len(self.keys_collected)} / 4"),
                (CYAN, "Move through all four colored rooms."),
                (GREEN, "Avoid the desks and display cases."),
                (PURPLE, "Press E when beside a glowing key."),
            ],
            "Find all four keys to reveal the hidden message.",
            f"KEYS REMAINING  {left}",
        )
        if len(self.keys_collected) == 4:
            draw_text(
                screen, "All four keys collected! The message is revealed.",
                MEDIUM, GREEN, 88, 594
            )
            continue_rect = pygame.Rect(866, 580, 190, 48)
            draw_button(screen, continue_rect, "READ MESSAGE  →", mouse_pos, GREEN)
            self.add_button(continue_rect, "START JUMBLE", "finish_keys", GREEN)

    def nearby_key(self):
        player_position = pygame.Vector2(self.player.center)
        available = [
            (index, pygame.Vector2(position))
            for index, (position, _) in enumerate(KEY_LOCATIONS)
            if index not in self.keys_collected
        ]
        if not available:
            return None
        index, position = min(
            available,
            key=lambda item: player_position.distance_to(item[1])
        )
        return index if player_position.distance_to(position) <= 64 else None

    def collect_nearby_key(self):
        index = self.nearby_key()
        if index is None:
            self.notify("Move next to a glowing key first.", GOLD)
            return
        self.keys_collected.add(index)
        self.collected_clues.add(index)
        self.inspected_clues.add(index)
        self.photographed_clues.add(index)
        self.score += 100
        self.notify(
            f"{KEY_LOCATIONS[index][1]} key and sealed evidence envelope collected! (+100)",
            GREEN
        )
        self.save_progress()

    def submit_jumble(self):
        if self.jumble_index >= len(WORD_PUZZLES):
            return
        if self.update_jumble_timer():
            return
        answer = self.jumble_answer.strip().upper()
        if not answer:
            self.notify("Type the word shown above, then press Enter.", GOLD)
            return
        _, solution, _ = WORD_PUZZLES[self.jumble_index]
        if answer == solution:
            self.jumble_solved.add(self.jumble_index)
            self.jumble_streak += 1
            bonus = 100 + min(self.jumble_streak - 1, 3) * 50
            self.score += bonus
            self.notify(
                f"Brilliant, Detective! {solution} decoded. +{bonus} XP — the next clue awaits!",
                GREEN
            )
            self.jumble_index += 1
            self.jumble_answer = ""
            self.jumble_time_left = JUMBLE_ROUND_SECONDS
            self.jumble_last_tick = pygame.time.get_ticks()
            self.ensure_jumble_scramble()
            if self.jumble_index >= len(WORD_PUZZLES):
                self.notify(
                    "Amazing work! Message decoded: THE SECRET DOOR IS BEHIND THE MOON PORTRAIT.",
                    GOLD
                )
                self.unlocked_level = max(self.unlocked_level, 2)
            self.save_progress()
        else:
            self.jumble_streak = 0
            self.notify("Close, Detective! Rearrange the letters and try again.", RED)
            self.jumble_answer = ""

    def update_jumble_timer(self):
        if self.jumble_index >= len(WORD_PUZZLES):
            return False
        now = pygame.time.get_ticks()
        elapsed = max(0, (now - self.jumble_last_tick) // 1000)
        if elapsed:
            self.jumble_last_tick += elapsed * 1000
            self.jumble_time_left = max(0, self.jumble_time_left - elapsed)
        if self.jumble_time_left > 0:
            return False

        self.jumble_time_left = JUMBLE_ROUND_SECONDS
        self.jumble_streak = 0
        self.jumble_answer = ""
        self.ensure_jumble_scramble()
        self.jumble_last_tick = now
        self.notify(
            "Time! The letters reshuffled. Take a breath and crack it this round!",
            GOLD,
        )
        self.save_progress()
        return True

    def draw_jumbled_message(self, mouse_pos):
        draw_text(screen, "02  /  THE JUMBLED MESSAGE", BIG, WHITE, 30, 112)
        draw_text(
            screen, "Crack each word before time runs out to uncover the hidden passage.",
            FONT, MUTED, 32, 158
        )
        panel = pygame.Rect(115, 205, 870, 420)
        draw_panel(screen, panel, (24, 33, 57), (88, 102, 151))

        self.update_jumble_timer()
        minutes, seconds = divmod(self.jumble_time_left, 60)
        timer_color = RED if self.jumble_time_left <= 10 else GOLD
        draw_text(
            screen, f"TIME LEFT  {minutes:02d}:{seconds:02d}",
            MEDIUM, timer_color, 155, 235
        )
        draw_text(
            screen, f"STREAK  x{self.jumble_streak}",
            MEDIUM, CYAN, 755, 235
        )
        progress = min(self.jumble_index, len(WORD_PUZZLES))
        draw_text(
            screen, f"WORDS SOLVED  {progress} / {len(WORD_PUZZLES)}",
            FONT, WHITE, 155, 280
        )
        timer_bar = pygame.Rect(155, 303, 790, 8)
        pygame.draw.rect(screen, BORDER, timer_bar, border_radius=4)
        timer_fill = timer_bar.copy()
        timer_fill.width = round(
            timer_bar.width * self.jumble_time_left / JUMBLE_ROUND_SECONDS
        )
        if timer_fill.width:
            pygame.draw.rect(
                screen, timer_color, timer_fill, border_radius=4
            )

        if self.jumble_index < len(WORD_PUZZLES):
            _, answer, hint = WORD_PUZZLES[self.jumble_index]
            scramble_rect = pygame.Rect(300, 318, 500, 82)
            pygame.draw.rect(screen, (42, 39, 76), scramble_rect, border_radius=14)
            pygame.draw.rect(screen, PURPLE, scramble_rect, 2, border_radius=14)
            scrambled_image = TITLE.render(self.jumble_scramble, True, GOLD)
            screen.blit(
                scrambled_image,
                scrambled_image.get_rect(center=scramble_rect.center),
            )
            draw_text(screen, f"Hint: {hint}", FONT, MUTED, 245, 416)

            draw_text(screen, "TYPE THE SCRAMBLED WORD", SMALL, CYAN, 425, 452)
            slot_width = 54
            slot_gap = 12
            slots_width = len(answer) * slot_width + (len(answer) - 1) * slot_gap
            slots_x = (WIDTH - slots_width) // 2
            slots_y = 474
            for index in range(len(answer)):
                slot = pygame.Rect(
                    slots_x + index * (slot_width + slot_gap),
                    slots_y,
                    slot_width,
                    54,
                )
                pygame.draw.rect(screen, (10, 17, 32), slot, border_radius=9)
                pygame.draw.rect(
                    screen,
                    CYAN if index < len(self.jumble_answer) else BORDER,
                    slot,
                    2,
                    border_radius=9,
                )
                letter = (
                    self.jumble_answer[index]
                    if index < len(self.jumble_answer)
                    else "_"
                )
                letter_color = WHITE if index < len(self.jumble_answer) else MUTED
                letter_image = MEDIUM.render(letter, True, letter_color)
                screen.blit(letter_image, letter_image.get_rect(center=slot.center))

            submit_rect = pygame.Rect(445, 542, 210, 42)
            draw_button(screen, submit_rect, "CHECK WORD  ↵", mouse_pos, GREEN)
            self.add_button(submit_rect, "CHECK WORD", "submit_jumble", GREEN)
            draw_text(
                screen, "Type every letter and press ENTER before the 30-second timer runs out.",
                SMALL, MUTED, 315, 596
            )
        else:
            draw_text(
                screen, "THE SECRET DOOR IS BEHIND THE MOON PORTRAIT",
                MEDIUM, GREEN, 205, 360
            )
            continue_rect = pygame.Rect(402, 470, 300, 55)
            draw_button(screen, continue_rect, "SEARCH FOR THE DOOR  →", mouse_pos, GREEN)
            self.add_button(continue_rect, "OPEN_LEVEL_3", "finish_jumble", GREEN)

    def update_flashlight(self):
        now = pygame.time.get_ticks()
        elapsed = max(0, (now - self.flashlight_last_tick) / 1000)
        self.flashlight_last_tick = now
        if self.flashlight_on:
            self.flashlight_energy = max(
                0, self.flashlight_energy - elapsed * 5
            )
            if self.flashlight_energy == 0:
                self.flashlight_on = False
                self.notify("Flashlight battery empty. Let it recharge.", RED)
        else:
            self.flashlight_energy = min(
                100, self.flashlight_energy + elapsed * 9
            )

    def nearest_secret_symbol(self):
        position = pygame.Vector2(self.player.center)
        symbols = [
            ("MOON", pygame.Vector2(165, 232)),
            ("EYE", pygame.Vector2(483, 249)),
            ("KEY", pygame.Vector2(709, 490)),
        ]
        nearby = [
            (name, location)
            for name, location in symbols
            if name not in self.secret_symbols_found
        ]
        if not nearby:
            return None
        name, location = min(
            nearby, key=lambda item: position.distance_to(item[1])
        )
        return name if position.distance_to(location) <= 75 else None

    def nearby_secret_key(self):
        if not self.secret_compartment_open or self.secret_key_found:
            return False
        return pygame.Vector2(self.player.center).distance_to((360, 520)) <= 145

    def secret_door_nearby(self):
        position = pygame.Vector2(self.player.center)
        doors = [
            ("decoy", pygame.Vector2(360, 500), 112),
            ("decoy", pygame.Vector2(560, 500), 100),
            ("moon", pygame.Vector2(766, 345), 88),
        ]
        nearby = [
            (name, location, radius)
            for name, location, radius in doors
            if position.distance_to(location) <= radius
        ]
        if not nearby:
            return None
        return min(
            nearby,
            key=lambda door: position.distance_to(door[1]),
        )[0]

    def record_secret_symbol(self, symbol):
        if symbol not in self.secret_symbols_found:
            self.notify("Reveal this symbol with your flashlight first.", GOLD)
            return
        if len(self.secret_door_code) >= len(SECRET_SYMBOLS):
            self.notify("The sequence is full. Clear it to try again.", GOLD)
            return

        self.secret_door_code.append(symbol)
        self.notify(f"{symbol} added to the inscription.", CYAN)
        if len(self.secret_door_code) == len(SECRET_SYMBOLS):
            if self.secret_door_code == SECRET_SYMBOLS:
                self.secret_compartment_open = True
                self.score += 150
                self.notify(
                    "Click! A hidden compartment opens behind the decoy door. Find the brass key!",
                    GOLD,
                )
            else:
                self.secret_door_code.clear()
                self.notify(
                    "The inscription flashes red and resets. Read the clues and try again.",
                    RED,
                )
        self.save_progress()

    def interact_secret_room(self):
        self.update_flashlight()
        symbol = self.nearest_secret_symbol()
        if symbol is not None:
            if not self.flashlight_on:
                self.notify("Turn on the flashlight with F to reveal this symbol.", GOLD)
                return
            self.secret_symbols_found.add(symbol)
            self.score += 100
            self.notify(f"Hidden symbol revealed: {symbol}. (+100)", GREEN)
            self.save_progress()
            return

        if self.nearby_secret_key():
            self.secret_key_found = True
            self.score += 150
            self.notify(
                "Brass key collected! The crescent-moon door matches your clue. (+150)",
                GOLD,
            )
            self.save_progress()
            return

        door = self.secret_door_nearby()
        if door == "moon":
            if not self.secret_key_found:
                self.notify(
                    "A crescent-moon keyhole glows. Find the hidden brass key first.",
                    GOLD,
                )
            else:
                self.secret_door_unlocked = True
                self.level = 3
                self.unlocked_level = max(self.unlocked_level, 3)
                self.player.topleft = (95, 570)
                self.score += 250
                self.notify(
                    "The brass key turns! You found the true passage. (+250)",
                    GREEN,
                )
                self.save_progress()
            return
        if door == "decoy":
            self.notify(
                "Decoy! The door is painted onto the stone. Keep searching.",
                RED,
            )
            return

        if not self.flashlight_on:
            self.notify("Switch on the flashlight with F, then search near each symbol.", GOLD)
        else:
            self.notify("Search the moon portrait, cracked mirror, and fallen frame.", CYAN)

    def draw_secret_door(self, mouse_pos, dt):
        room = pygame.Rect(35, 108, 800, 542)
        pygame.draw.rect(screen, (19, 22, 43), room, border_radius=15)
        pygame.draw.rect(screen, (55, 60, 94), room, 2, border_radius=15)
        for x in range(55, 820, 48):
            pygame.draw.line(screen, (28, 31, 57), (x, 120), (x, 638), 1)

        paintings = [
            pygame.Rect(92, 158, 145, 150),
            pygame.Rect(405, 175, 156, 150),
            pygame.Rect(645, 385, 130, 130),
        ]
        for index, frame in enumerate(paintings):
            pygame.draw.rect(screen, (129, 91, 51), frame, border_radius=5)
            pygame.draw.rect(screen, GOLD, frame, 4, border_radius=5)
            inner = frame.inflate(-14, -14)
            pygame.draw.rect(screen, (34, 42, 72), inner)
            if index == 0:
                pygame.draw.circle(screen, (242, 222, 166), inner.center, 30)
                pygame.draw.circle(screen, (34, 42, 72), (inner.centerx + 12, inner.centery - 8), 28)
            elif index == 1:
                pygame.draw.circle(screen, (74, 138, 159), inner.center, 32, 3)
                pygame.draw.ellipse(screen, CYAN, (inner.centerx - 26, inner.centery - 12, 52, 24), 3)
                pygame.draw.circle(screen, WHITE, inner.center, 6)
            else:
                pygame.draw.line(screen, (180, 152, 90), (inner.x + 30, inner.y + 20), (inner.x + 30, inner.y + 67), 7)
                pygame.draw.circle(screen, GOLD, (inner.x + 43, inner.y + 34), 12, 4)

        # The first panel conceals the key compartment; the moon door is the exit.
        doors = [
            (pygame.Rect(300, 420, 120, 180), "SUN", False),
            (pygame.Rect(500, 420, 120, 180), "EYE", False),
            (pygame.Rect(710, 255, 112, 180), "MOON", True),
        ]
        for rect, mark, is_real in doors:
            is_compartment = mark == "SUN"
            if is_compartment and self.secret_compartment_open:
                alcove = rect.inflate(-18, -18)
                pygame.draw.rect(screen, (7, 13, 27), alcove, border_radius=5)
                pygame.draw.rect(screen, GOLD, rect, 4, border_radius=7)
                pygame.draw.polygon(
                    screen, (112, 77, 53),
                    [
                        (rect.x + 8, rect.y + 8),
                        (rect.x + 37, rect.y + 28),
                        (rect.x + 37, rect.bottom - 28),
                        (rect.x + 8, rect.bottom - 8),
                    ],
                )
                pygame.draw.line(
                    screen, GOLD,
                    (rect.x + 8, rect.y + 8),
                    (rect.x + 8, rect.bottom - 8),
                    3,
                )
                draw_text(
                    screen, "HIDDEN KEY ALCOVE", SMALL, GOLD,
                    rect.x - 15, rect.bottom + 8,
                )
                continue

            unlocked_look = is_real and self.secret_key_found
            is_moon_exit = mark == "MOON"
            fill = (
                (41, 76, 80) if is_moon_exit and not unlocked_look
                else (36, 91, 76) if unlocked_look
                else (61, 48, 67)
            )
            edge = (
                CYAN if is_moon_exit and not unlocked_look
                else GREEN if unlocked_look
                else (143, 105, 128)
            )
            pygame.draw.rect(screen, fill, rect, border_radius=9)
            pygame.draw.rect(screen, edge, rect, 3, border_radius=9)
            if is_moon_exit:
                pygame.draw.rect(
                    screen, GOLD, rect.inflate(14, 14), 3, border_radius=12
                )
                draw_text(
                    screen, "MOON EXIT",
                    MEDIUM if self.secret_key_found else SMALL,
                    GOLD if self.secret_key_found else CYAN,
                    rect.x + 9, rect.y - 29,
                )
            pygame.draw.circle(
                screen, GOLD if is_moon_exit else MUTED,
                (rect.centerx, rect.y + 42), 17, 2
            )
            if is_moon_exit:
                pygame.draw.circle(
                    screen, GOLD, (rect.centerx, rect.y + 42), 10
                )
                pygame.draw.circle(
                    screen, fill, (rect.centerx + 5, rect.y + 38), 9
                )
            else:
                mark_image = MEDIUM.render(
                    mark[0],
                    True,
                    (166, 155, 177),
                )
                screen.blit(mark_image, mark_image.get_rect(
                    center=(rect.centerx, rect.y + 42)
                ))
            if is_moon_exit:
                door_label = "MOON EXIT  ·  USE BRASS KEY"
                if self.secret_key_found:
                    door_label = "MOON EXIT  ·  PRESS E"
                draw_text(
                    screen, door_label, SMALL,
                    GREEN if self.secret_key_found else CYAN,
                    rect.x - 52, rect.bottom + 8,
                )
            elif self.secret_key_found:
                draw_text(screen, "DECOY", SMALL, MUTED, rect.x + 28, rect.bottom + 8)

        # Faint markers keep the search locations discoverable; the flashlight
        # reveals each symbol's identity.
        symbol_spots = [
            ("MOON", (165, 232), GOLD),
            ("EYE", (483, 249), CYAN),
            ("KEY", (709, 490), PURPLE),
        ]
        for name, point, color in symbol_spots:
            if name in self.secret_symbols_found:
                draw_text(screen, f"{name} FOUND", SMALL, GREEN, point[0] - 42, point[1] + 51)
            elif self.flashlight_on:
                pygame.draw.circle(screen, (12, 18, 31), point, 30)
                pygame.draw.circle(screen, color, point, 26, 4)
                pygame.draw.circle(screen, color, point, 8)
                label = MEDIUM.render(name, True, WHITE)
                label_rect = label.get_rect(center=(point[0], point[1] - 43))
                pygame.draw.rect(
                    screen, (10, 17, 32), label_rect.inflate(18, 10),
                    border_radius=7
                )
                screen.blit(label, label_rect)
            else:
                pygame.draw.circle(screen, (83, 98, 129), point, 17, 2)
                question = MEDIUM.render("?", True, (142, 157, 184))
                screen.blit(question, question.get_rect(center=point))

        if self.secret_compartment_open and not self.secret_key_found:
            key_position = (360, 520)
            pulse = int(3 * abs(math.sin(pygame.time.get_ticks() / 180)))
            pygame.draw.circle(screen, (36, 29, 12), key_position, 25 + pulse)
            pygame.draw.circle(screen, GOLD, key_position, 19 + pulse, 3)
            pygame.draw.circle(screen, GOLD, (key_position[0] - 4, key_position[1]), 7)
            pygame.draw.line(
                screen, GOLD,
                (key_position[0] + 2, key_position[1]),
                (key_position[0] + 17, key_position[1]),
                4,
            )
            pygame.draw.line(
                screen, GOLD,
                (key_position[0] + 12, key_position[1]),
                (key_position[0] + 12, key_position[1] + 6),
                3,
            )
            draw_text(screen, "BRASS KEY", SMALL, GOLD, 321, 548)
        elif self.secret_key_found:
            draw_text(screen, "BRASS KEY  ✓", SMALL, GREEN, 67, 606)

        # Keep the light subtle so it does not wash out the clue labels.
        if self.flashlight_on:
            cone = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
            pygame.draw.circle(cone, (72, 178, 222, 34), self.player.center, 180)
            pygame.draw.circle(cone, (107, 197, 234, 42), self.player.center, 95)
            screen.blit(cone, (0, 0))

        obstacles = [
            pygame.Rect(285, 390, 150, 18),
            pygame.Rect(285, 575, 52, 18),
            pygame.Rect(383, 575, 52, 18),
            pygame.Rect(285, 390, 18, 203),
            pygame.Rect(417, 390, 18, 203),
            pygame.Rect(500, 420, 18, 180),
            pygame.Rect(602, 420, 18, 180),
            pygame.Rect(710, 255, 18, 75),
            pygame.Rect(814, 255, 18, 180),
        ]
        bounds = pygame.Rect(44, 117, 782, 524)
        if not self.paused and not self.notebook_open:
            self.move_player(dt, bounds, obstacles)
        self.draw_player()
        self.update_flashlight()

        nearby_symbol = self.nearest_secret_symbol()
        nearby_key = self.nearby_secret_key()
        nearby_door = self.secret_door_nearby()
        if nearby_symbol or nearby_key or nearby_door:
            prompt_rect = pygame.Rect(250, 590, 390, 34)
            pygame.draw.rect(screen, (8, 14, 27), prompt_rect, border_radius=8)
            pygame.draw.rect(screen, CYAN, prompt_rect, 2, border_radius=8)
            if nearby_key:
                prompt_text = "PRESS E TO TAKE THE BRASS KEY"
            elif nearby_symbol and not self.flashlight_on:
                prompt_text = "PRESS F TO TURN ON FLASHLIGHT"
            elif nearby_symbol:
                prompt_text = f"PRESS E TO REVEAL {nearby_symbol}"
            elif (
                nearby_door == "decoy"
                and self.secret_compartment_open
                and not self.secret_key_found
            ):
                prompt_text = "OPEN SUN ALCOVE: MOVE TO THE GLOWING KEY"
            elif nearby_door == "moon" and self.secret_key_found:
                prompt_text = "PRESS E TO UNLOCK THE MOON DOOR"
            elif nearby_door == "moon":
                prompt_text = "MOON DOOR: FIND THE BRASS KEY"
            else:
                prompt_text = "PRESS E TO TEST THIS DOOR"
            prompt = FONT.render(prompt_text, True, WHITE)
            screen.blit(prompt, prompt.get_rect(center=prompt_rect.center))

        self.draw_world_sidebar(
            "THE SECRET DOOR",
            [
                (GOLD, f"Symbols: {len(self.secret_symbols_found)} / 3"),
                (CYAN, f"Flashlight: {'ON' if self.flashlight_on else 'OFF'}  ·  press F"),
                (PURPLE, f"Battery: {int(self.flashlight_energy)}%"),
                (GREEN, "Key: found" if self.secret_key_found else (
                    "Key: find the moon-sequence compartment"
                    if self.secret_compartment_open else "Key: still hidden"
                )),
            ],
            (
                "The glowing MOON EXIT on the right is the true door. Walk up and press E."
                if self.secret_key_found else
                "After the symbol sequence opens the SUN panel, enter through its bottom doorway and take the glowing brass key."
                if self.secret_compartment_open else
                "Reveal all symbols, enter MOON → EYE → KEY, then search the false door for a key."
            ),
            (
                "FIND THE MOON DOOR  ·  KEY READY"
                if self.secret_key_found else
                "TAKE THE KEY  ·  ALCOVE IS OPEN"
                if self.secret_compartment_open else
                f"FIND SYMBOLS  ·  {len(self.secret_symbols_found)}/3"
            ),
        )

        if len(self.secret_symbols_found) == 3:
            draw_text(
                screen,
                "THE INSCRIPTION: MOON ABOVE EYE. THE KEY MARK IS LAST.",
                SMALL, GOLD, 65, 531
            )
            for index, (name, color) in enumerate(
                (("MOON", GOLD), ("EYE", CYAN), ("KEY", PURPLE))
            ):
                rect = pygame.Rect(75 + index * 135, 554, 120, 42)
                draw_button(screen, rect, name, mouse_pos, color)
                self.add_button(rect, name, ("secret_symbol", name), color)
            clear_rect = pygame.Rect(484, 554, 110, 42)
            draw_button(screen, clear_rect, "CLEAR", mouse_pos, RED)
            self.add_button(clear_rect, "CLEAR", "clear_symbols", RED)
            draw_text(
                screen,
                f"SEQUENCE: {' → '.join(self.secret_door_code) or 'choose the symbols'}",
                SMALL, WHITE, 72, 608
            )

    def draw_flashlight_cone(self):
        darkness = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
        darkness.fill((4, 6, 17, 72))
        screen.blit(darkness, (0, 0))
        if self.flashlight_on:
            light = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
            pygame.draw.circle(
                light, (80, 190, 235, 75), self.player.center, 150
            )
            pygame.draw.circle(
                light, (146, 220, 255, 72), self.player.center, 75
            )
            screen.blit(light, (0, 0))

    def answer_aptitude_question(self, selected_index):
        if self.quiz_show_answer or self.quiz_index >= len(APTITUDE_QUESTIONS):
            return
        question = APTITUDE_QUESTIONS[self.quiz_index]
        hard_mode = self.quiz_streak >= 2
        answer = question.get("hard_answer", question["answer"]) if hard_mode else question["answer"]
        explanation = question["hard"] if hard_mode else question["easy"]
        self.quiz_selected = selected_index
        self.quiz_last_correct = selected_index == answer
        self.quiz_last_explanation = explanation
        self.quiz_show_answer = True
        if self.quiz_last_correct:
            self.quiz_streak += 1
            self.quiz_score += 1
            points = 100 + min(self.quiz_streak - 1, 3) * 50
            self.score += points
            self.notify(f"Correct deduction! +{points} XP.", GREEN)
        else:
            self.quiz_streak = 0
            self.notify("Not this time. Read the reasoning, then continue.", RED)
        self.save_progress()

    def advance_aptitude_question(self):
        if not self.quiz_show_answer:
            return
        self.quiz_index += 1
        self.quiz_show_answer = False
        self.quiz_selected = None
        if self.quiz_index >= len(APTITUDE_QUESTIONS):
            self.quiz_completed = True
            self.notify(
                "Aptitude assessment complete. Your final case file is ready.",
                GOLD,
            )
        self.save_progress()

    def begin_final_case(self):
        if not self.quiz_completed:
            self.notify("Complete the aptitude assessment before opening the final case.", RED)
            return
        self.level = 5
        self.unlocked_level = max(self.unlocked_level, 5)
        if not self.body_discovered and self.final_case_stage == "discovery":
            self.player.topleft = (80, 250)
        self.notify(
            "LEVEL 6: search the east wing. Find Dr. Vale and investigate with E.",
            GREEN,
        )
        self.save_progress()

    def draw_aptitude_test(self, mouse_pos):
        draw_text(screen, "05  /  DETECTIVE APTITUDE TEST", BIG, WHITE, 30, 112)
        draw_text(
            screen, "Use patterns, logic, directions, codes, and evidence analysis.",
            FONT, MUTED, 32, 158
        )
        panel = pygame.Rect(115, 205, 870, 420)
        draw_panel(screen, panel, (23, 33, 57), (80, 110, 157))

        if self.quiz_index >= len(APTITUDE_QUESTIONS):
            draw_text(screen, "ASSESSMENT COMPLETE", BIG, GREEN, 330, 290)
            draw_text(
                screen, f"Correct answers: {self.quiz_score} / {len(APTITUDE_QUESTIONS)}",
                MEDIUM, GOLD, 375, 355
            )
            draw_paragraph(
                screen, "The deductions you earned are added to the final case file.",
                FONT, WHITE, 280, 405, 540, 25
            )
            continue_rect = pygame.Rect(385, 500, 330, 54)
            draw_button(
                screen, continue_rect, "OPEN LEVEL 6  →",
                mouse_pos, GREEN,
            )
            self.add_button(
                continue_rect, "OPEN LEVEL 6", "begin_final_case", GREEN
            )
            return

        question = APTITUDE_QUESTIONS[self.quiz_index]
        hard_mode = self.quiz_streak >= 2
        prompt = question.get("hard_question", question["question"]) if hard_mode else question["question"]
        choices = question.get("hard_choices", question["choices"]) if hard_mode else question["choices"]

        draw_text(
            screen, f"QUESTION {self.quiz_index + 1} / {len(APTITUDE_QUESTIONS)}",
            SMALL, GOLD, 155, 235
        )
        draw_text(
            screen, question["category"], MEDIUM, CYAN, 155, 265
        )
        difficulty = "HARD MODE  ·  streak bonus active" if hard_mode else "CASE FILE CHALLENGE"
        draw_text(screen, difficulty, SMALL, PURPLE, 745, 270)
        draw_paragraph(screen, prompt, MEDIUM, WHITE, 155, 315, 780, 30)

        for index, choice in enumerate(choices):
            x = 160 + (index % 2) * 390
            y = 400 + (index // 2) * 62
            rect = pygame.Rect(x, y, 365, 48)
            selected = self.quiz_selected == index
            color = GREEN if selected and self.quiz_last_correct else RED if selected else PURPLE
            draw_button(
                screen, rect, f"{chr(65 + index)}. {choice}",
                mouse_pos, color, not self.quiz_show_answer
            )
            self.add_button(
                rect, choice, ("aptitude_answer", index),
                color, not self.quiz_show_answer
            )

        draw_text(
            screen, f"CORRECT  {self.quiz_score} / {self.quiz_index}",
            FONT, GOLD, 160, 548
        )
        if self.quiz_show_answer:
            explanation_rect = pygame.Rect(430, 535, 510, 56)
            pygame.draw.rect(screen, (14, 24, 42), explanation_rect, border_radius=8)
            explanation_color = GREEN if self.quiz_last_correct else GOLD
            draw_paragraph(
                screen, self.quiz_last_explanation, SMALL,
                explanation_color, explanation_rect.x + 12,
                explanation_rect.y + 7, explanation_rect.width - 24, 18
            )
            next_rect = pygame.Rect(770, 595, 170, 38)
            draw_button(screen, next_rect, "NEXT QUESTION  →", mouse_pos, CYAN)
            self.add_button(next_rect, "NEXT QUESTION", "next_aptitude", CYAN)

    def play_discovery_sting(self):
        try:
            if not pygame.mixer.get_init():
                pygame.mixer.init(frequency=22050, size=-16, channels=1)
            samples = array("h")
            for frequency, duration in ((392, 0.11), (523, 0.14), (659, 0.2)):
                for sample in range(int(22050 * duration)):
                    envelope = 1 - sample / (22050 * duration)
                    value = int(
                        2400 * envelope
                        * math.sin(2 * math.pi * frequency * sample / 22050)
                    )
                    samples.append(value)
            pygame.mixer.Sound(buffer=samples).play()
        except (pygame.error, OSError):
            pass

    def discover_body(self):
        if self.body_discovered or self.final_case_stage != "discovery":
            return
        body_position = pygame.Vector2(880, 540)
        if pygame.Vector2(self.player.center).distance_to(body_position) > 78:
            self.notify("Search the east wing. Move close to the figure and press E.", GOLD)
            return
        self.body_discovered = True
        self.final_case_stage = "discovery_dialogue"
        self.score += 100
        self.play_discovery_sting()
        self.notify("Dr. Adrian Vale has been found. The crime-scene investigation begins.", GOLD)
        self.save_progress()

    def final_case_obstacles(self):
        return [
            pygame.Rect(245, 315, 105, 62),
            pygame.Rect(450, 240, 112, 52),
            pygame.Rect(650, 390, 100, 58),
            pygame.Rect(360, 520, 90, 44),
        ]

    def draw_final_room(self, dt, evidence_mode=False):
        room = pygame.Rect(30, 204, 1040, 430)
        draw_panel(screen, room, (12, 20, 37), (75, 93, 132))
        for x in (286, 522, 758):
            pygame.draw.line(screen, (52, 65, 95), (x, 205), (x, 344), 2)
            pygame.draw.line(screen, (52, 65, 95), (x, 436), (x, 633), 2)
            doorway = pygame.Rect(x - 15, 344, 30, 92)
            pygame.draw.rect(screen, (48, 35, 52), doorway, border_radius=4)
            pygame.draw.rect(screen, (147, 105, 78), doorway, 2, border_radius=4)
            pygame.draw.line(
                screen, (188, 142, 94),
                (doorway.x + 6, doorway.y + 8),
                (doorway.x + 6, doorway.bottom - 8), 2
            )
            pygame.draw.circle(
                screen, GOLD, (doorway.right - 6, doorway.centery), 3
            )
        for rect, color in (
            (pygame.Rect(245, 315, 105, 62), (38, 46, 70)),
            (pygame.Rect(450, 240, 112, 52), (34, 43, 67)),
            (pygame.Rect(650, 390, 100, 58), (39, 44, 66)),
            (pygame.Rect(360, 520, 90, 44), (44, 42, 67)),
        ):
            pygame.draw.rect(screen, color, rect, border_radius=8)
            pygame.draw.rect(screen, (76, 88, 119), rect, 2, border_radius=8)

        draw_text(screen, "WEST HALL", SMALL, MUTED, 76, 224)
        draw_text(screen, "EAST WING", SMALL, MUTED, 855, 224)
        draw_text(screen, "STORM OUTSIDE  ·  POWER FLICKERING", SMALL, CYAN, 352, 608)

        bounds = room.inflate(-24, -24)
        obstacles = self.final_case_obstacles()
        self.move_player(dt, bounds, obstacles)

        if evidence_mode:
            for index, clue in enumerate(FINAL_CASE_CLUES):
                x, y = clue["position"]
                found = index in self.final_clues_found
                color = GREEN if found else clue["color"]
                pygame.draw.circle(screen, (8, 12, 27), (x, y), 20)
                pygame.draw.circle(screen, color, (x, y), 15, 3)
                label = "✓" if found else str(index + 1)
                number = SMALL.render(label, True, color)
                screen.blit(number, number.get_rect(center=(x, y)))
                draw_text(
                    screen, clue["name"], SMALL,
                    GREEN if found else WHITE, x - 66, y + 23
                )
        else:
            nearby = pygame.Vector2(self.player.center).distance_to((880, 540)) <= 122
            if self.body_discovered or nearby:
                pygame.draw.ellipse(screen, (6, 10, 18), (844, 548, 76, 25))
                pygame.draw.ellipse(screen, (139, 154, 183), (853, 529, 51, 21))
                pygame.draw.circle(screen, (139, 154, 183), (906, 539), 11)
                draw_text(
                    screen, "DR. VALE" if self.body_discovered else "BODY?",
                    MEDIUM, GOLD, 845, 488
                )
            else:
                draw_text(screen, "SEARCH THE EAST WING", SMALL, CYAN, 817, 553)
        self.draw_player()

        if evidence_mode:
            nearest = self.nearest_final_clue()
            prompt = (
                f"E  INVESTIGATE  ·  {FINAL_CASE_CLUES[nearest]['name']}"
                if nearest is not None else "WASD / ARROWS MOVE  ·  E INVESTIGATE NEARBY CLUES"
            )
        else:
            prompt = (
                "E  EXAMINE DR. VALE"
                if pygame.Vector2(self.player.center).distance_to((880, 540)) <= 78
                else "WASD / ARROWS MOVE  ·  FIND DR. VALE IN THE EAST WING"
            )
        prompt_rect = pygame.Rect(300, 570, 500, 32)
        pygame.draw.rect(screen, (7, 12, 27), prompt_rect, border_radius=9)
        draw_text(
            screen, prompt, SMALL, GOLD if prompt.startswith("E  ") else WHITE,
            prompt_rect.x + 12, prompt_rect.y + 7
        )

    def nearest_final_clue(self):
        available = [
            (index, pygame.Vector2(clue["position"]))
            for index, clue in enumerate(FINAL_CASE_CLUES)
            if index not in self.final_clues_found
        ]
        if not available:
            return None
        index, position = min(
            available,
            key=lambda entry: pygame.Vector2(self.player.center).distance_to(entry[1]),
        )
        return index if pygame.Vector2(self.player.center).distance_to(position) <= 70 else None

    def investigate_final_clue(self):
        if self.final_case_stage != "evidence":
            return
        index = self.nearest_final_clue()
        if index is None:
            self.notify("Move close to a glowing evidence marker, then press E.", GOLD)
            return
        if index not in self.final_clues_found:
            self.final_clues_found.add(index)
            self.score += 75
            clue = FINAL_CASE_CLUES[index]
            self.notify(f"{clue['name']}: {clue['detail']} (+75 XP)", GREEN)
            if len(self.final_clues_found) == len(FINAL_CASE_CLUES):
                self.notify("All six clues secured. Interview the four suspects next.", GOLD)
            self.save_progress()

    def draw_final_discovery_dialogue(self, mouse_pos):
        overlay = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
        overlay.fill((3, 7, 18, 215))
        screen.blit(overlay, (0, 0))
        box = pygame.Rect(170, 170, 760, 385)
        draw_panel(screen, box, (18, 29, 50), GOLD)
        draw_text(screen, "A BODY IN THE EAST WING", BIG, GOLD, 215, 205)
        draw_paragraph(
            screen,
            "Dr. Adrian Vale lies motionless beside the laboratory entrance. "
            "There is no graphic scene—only a broken watch, the thunder outside, "
            "and a room that should have been locked.",
            FONT, WHITE, 215, 270, 650, 27
        )
        draw_paragraph(
            screen,
            "The storm has cut off the mansion. Secure the clues, compare the "
            "four alibis, and reconstruct what happened before naming the killer.",
            FONT, CYAN, 215, 374, 650, 25
        )
        continue_rect = pygame.Rect(390, 478, 320, 48)
        draw_button(screen, continue_rect, "SECURE THE CRIME SCENE  →", mouse_pos, GREEN)
        self.add_button(continue_rect, "SECURE CRIME SCENE", "continue_final_discovery", GREEN)

    def draw_final_evidence_stage(self, mouse_pos, dt):
        draw_text(screen, "06  /  CRIME SCENE", BIG, WHITE, 30, 112)
        draw_text(
            screen,
            f"Secure each glowing clue with E  ·  {len(self.final_clues_found)} / 6 collected",
            FONT, MUTED, 32, 158
        )
        self.draw_final_room(dt, evidence_mode=True)
        if len(self.final_clues_found) == len(FINAL_CASE_CLUES):
            rect = pygame.Rect(785, 575, 250, 42)
            draw_button(screen, rect, "INTERVIEW SUSPECTS  →", mouse_pos, GREEN)
            self.add_button(rect, "INTERVIEW SUSPECTS", "final_to_interviews", GREEN)

    def open_final_interview(self, index):
        self.final_active_suspect = index
        self.dialogue_open = True

    def draw_final_interviews(self, mouse_pos):
        draw_text(screen, "06  /  SUSPECT INTERVIEWS", BIG, WHITE, 30, 112)
        draw_text(
            screen, "Question each suspect. Their biographies, motives, alibis, and statements matter.",
            FONT, MUTED, 32, 158
        )
        for index, suspect in enumerate(FINAL_SUSPECT_PROFILES):
            x = 48 + (index % 2) * 510
            y = 205 + (index // 2) * 190
            rect = pygame.Rect(x, y, 490, 170)
            interviewed = index in self.final_suspects_interviewed
            draw_panel(screen, rect, (20, 32, 54), GREEN if interviewed else (79, 90, 123))
            draw_text(screen, suspect["name"], MEDIUM, GREEN if interviewed else WHITE, x + 20, y + 15)
            draw_paragraph(screen, suspect["biography"], SMALL, CYAN, x + 20, y + 52, 445, 20)
            draw_paragraph(screen, f"Motive: {suspect['motive']}", SMALL, GOLD, x + 20, y + 79, 445, 20)
            status = "INTERVIEW RECORDED ✓" if interviewed else "OPEN INTERVIEW  →"
            button_rect = pygame.Rect(x + 20, y + 123, 210, 34)
            draw_button(screen, button_rect, status, mouse_pos, GREEN if interviewed else PURPLE)
            self.add_button(button_rect, status, ("open_final_interview", index), GREEN if interviewed else PURPLE)
        count = len(self.final_suspects_interviewed)
        draw_text(screen, f"INTERVIEWS RECORDED  {count} / 4", SMALL, GOLD, 55, 598)
        if count == len(FINAL_SUSPECT_PROFILES):
            rect = pygame.Rect(765, 584, 270, 42)
            draw_button(screen, rect, "RECONSTRUCT TIMELINE  →", mouse_pos, GREEN)
            self.add_button(rect, "RECONSTRUCT TIMELINE", "final_to_timeline", GREEN)

        if self.dialogue_open and self.final_active_suspect is not None:
            self.draw_final_suspect_dialogue(mouse_pos)

    def draw_final_suspect_dialogue(self, mouse_pos):
        suspect = FINAL_SUSPECT_PROFILES[self.final_active_suspect]
        overlay = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
        overlay.fill((3, 7, 18, 218))
        screen.blit(overlay, (0, 0))
        box = pygame.Rect(135, 112, 830, 510)
        draw_panel(screen, box, (18, 29, 50), CYAN)
        draw_text(screen, "INTERVIEW TRANSCRIPT", SMALL, GOLD, 170, 140)
        draw_text(screen, suspect["name"], BIG, WHITE, 170, 169)
        y = draw_paragraph(screen, suspect["biography"], FONT, CYAN, 170, 220, 750, 24) + 8
        draw_text(screen, "MOTIVE", SMALL, GOLD, 170, y)
        y = draw_paragraph(screen, suspect["motive"], FONT, WHITE, 170, y + 23, 750, 23) + 7
        draw_text(screen, "ALIBI", SMALL, GOLD, 170, y)
        y = draw_paragraph(screen, suspect["alibi"], FONT, WHITE, 170, y + 23, 750, 23) + 7
        draw_text(screen, "STATEMENT", SMALL, GOLD, 170, y)
        y = draw_paragraph(screen, suspect["statement"], FONT, WHITE, 170, y + 23, 750, 23)
        if set(suspect["comparison_clues"]).issubset(self.final_clues_found):
            draw_text(screen, "EVIDENCE CHECK", SMALL, GOLD, 170, y + 7)
            draw_paragraph(
                screen, suspect["comparison"], SMALL, CYAN,
                170, y + 29, 750, 20
            )
        button_rect = pygame.Rect(405, 555, 290, 42)
        close_rect = pygame.Rect(720, 555, 145, 42)
        interviewed = self.final_active_suspect in self.final_suspects_interviewed
        label = "INTERVIEW ALREADY RECORDED" if interviewed else "RECORD INTERVIEW  (+50 XP)"
        draw_button(screen, button_rect, label, mouse_pos, GREEN if interviewed else CYAN)
        self.add_button(button_rect, label, ("record_final_interview", self.final_active_suspect), CYAN, not interviewed)
        draw_button(screen, close_rect, "CLOSE", mouse_pos, (87, 98, 125))
        self.add_button(close_rect, "CLOSE", "close_dialogue", (87, 98, 125))

    def draw_final_timeline(self, mouse_pos):
        draw_text(screen, "06  /  RECONSTRUCT THE TIMELINE", BIG, WHITE, 30, 112)
        draw_text(
            screen, "Select the events in the order they occurred. You can undo and try again.",
            FONT, MUTED, 32, 158
        )
        available_panel = pygame.Rect(40, 205, 505, 420)
        order_panel = pygame.Rect(565, 205, 505, 420)
        draw_panel(screen, available_panel, (20, 31, 53), (84, 105, 144))
        draw_panel(screen, order_panel, (20, 31, 53), (84, 105, 144))
        draw_text(screen, "AVAILABLE EVENTS", MEDIUM, CYAN, 65, 224)
        draw_text(screen, "YOUR ORDER", MEDIUM, GOLD, 590, 224)
        remaining = [event for event in FINAL_TIMELINE_EVENTS if event["id"] not in self.final_timeline_order]
        for index, event in enumerate(remaining):
            y = 266 + index * 77
            rect = pygame.Rect(65, y, 455, 64)
            draw_button(screen, rect, f"{event['time']}  ·  {event['text']}", mouse_pos, PURPLE)
            self.add_button(rect, event["text"], ("timeline_event", event["id"]), PURPLE)
        if not remaining:
            draw_text(screen, "All events placed.", SMALL, GREEN, 70, 280)
        for index, event_id in enumerate(self.final_timeline_order):
            event = next(event for event in FINAL_TIMELINE_EVENTS if event["id"] == event_id)
            y = 268 + index * 70
            draw_text(screen, f"{index + 1}.", FONT, CYAN, 595, y)
            draw_text(screen, event["time"], SMALL, GOLD, 628, y)
            draw_paragraph(screen, event["text"], SMALL, WHITE, 628, y + 19, 400, 19)
        if self.final_timeline_feedback:
            draw_paragraph(screen, self.final_timeline_feedback, SMALL, GOLD, 590, 548, 430, 19)
        if self.final_timeline_order:
            undo_rect = pygame.Rect(590, 584, 145, 32)
            draw_button(screen, undo_rect, "UNDO LAST", mouse_pos, (87, 61, 93))
            self.add_button(undo_rect, "UNDO LAST", "timeline_undo", (87, 61, 93))
        if len(self.final_timeline_order) == len(FINAL_TIMELINE_EVENTS):
            validate_rect = pygame.Rect(795, 578, 235, 40)
            label = "TIMELINE VERIFIED  →" if self.final_timeline_complete else "VALIDATE TIMELINE"
            draw_button(screen, validate_rect, label, mouse_pos, GREEN if self.final_timeline_complete else GOLD)
            self.add_button(validate_rect, label, "validate_final_timeline", GOLD)

    def validate_final_timeline(self):
        if len(self.final_timeline_order) != len(FINAL_TIMELINE_EVENTS):
            self.final_timeline_feedback = "Place all four events before validating."
            self.notify(self.final_timeline_feedback, RED)
            return
        correct_order = [event["id"] for event in FINAL_TIMELINE_EVENTS]
        if self.final_timeline_order != correct_order:
            mismatch = next(
                index for index, event_id in enumerate(self.final_timeline_order)
                if event_id != correct_order[index]
            )
            event = next(
                event for event in FINAL_TIMELINE_EVENTS
                if event["id"] == self.final_timeline_order[mismatch]
            )
            self.final_timeline_feedback = (
                f"Not quite: {event['reason']}"
            )
            self.notify(self.final_timeline_feedback, RED)
            return
        self.final_timeline_complete = True
        self.final_case_stage = "accusation"
        if not self.final_timeline_awarded:
            self.final_timeline_awarded = True
            self.score += 200
        self.final_timeline_feedback = "Timeline verified. The 10:05 override preceded the 10:15 attack."
        self.notify("Timeline correct! (+200 XP) Present your evidence and make the final accusation.", GREEN)
        self.save_progress()

    def draw_final_accusation(self, mouse_pos):
        draw_text(screen, "06  /  MAKE YOUR ACCUSATION", BIG, WHITE, 30, 112)
        draw_text(
            screen, "Choose the killer, murder location, and at least two supporting clues.",
            FONT, MUTED, 32, 158
        )
        evidence_panel = pygame.Rect(40, 205, 500, 250)
        choice_panel = pygame.Rect(560, 205, 510, 410)
        draw_panel(screen, evidence_panel, (20, 31, 53), (84, 105, 144))
        draw_panel(screen, choice_panel, (20, 31, 53), (84, 105, 144))
        draw_text(screen, f"SUPPORTING EVIDENCE  {len(self.final_evidence_presented)} / 6", MEDIUM, CYAN, 65, 222)
        for index, clue in enumerate(FINAL_CASE_CLUES):
            x = 65 + (index % 2) * 235
            y = 268 + (index // 2) * 52
            rect = pygame.Rect(x, y, 220, 42)
            selected = index in self.final_evidence_presented
            color = GREEN if selected else clue["color"]
            draw_button(screen, rect, ("✓ " if selected else "") + clue["name"], mouse_pos, color)
            self.add_button(rect, clue["name"], ("final_case_evidence", index), color)

        draw_text(screen, "WHO DID IT?", SMALL, GOLD, 585, 225)
        for index, suspect in enumerate(FINAL_SUSPECT_PROFILES):
            x = 585 + (index % 2) * 230
            y = 252 + (index // 2) * 47
            rect = pygame.Rect(x, y, 215, 38)
            selected = self.final_suspect == suspect["name"]
            draw_button(screen, rect, suspect["name"], mouse_pos, GREEN if selected else PURPLE)
            self.add_button(rect, suspect["name"], ("final_suspect", suspect["name"]), GREEN if selected else PURPLE)

        draw_text(screen, "WHERE?", SMALL, GOLD, 585, 359)
        for index, location in enumerate(FINAL_LOCATIONS):
            x = 585 + (index % 2) * 230
            y = 386 + (index // 2) * 43
            rect = pygame.Rect(x, y, 215, 36)
            selected = self.final_location == location
            draw_button(screen, rect, location, mouse_pos, GREEN if selected else CYAN)
            self.add_button(rect, location, ("final_location", location), GREEN if selected else CYAN)

        core_clues = {1, 3, 4, 5}
        supported = (
            1 in self.final_evidence_presented
            and bool(core_clues.intersection(self.final_evidence_presented) - {1})
        )
        draw_text(
            screen,
            "Include the 10:05 terminal log and another clue linking Victor to the lab.",
            SMALL, MUTED, 65, 424
        )
        if len(self.final_evidence_presented) < 2:
            evidence_status = "Select at least two pieces of evidence."
        elif not supported and self.final_suspect == CORRECT_SUSPECT:
            evidence_status = "The terminal log plus chemical, drawer, or passage evidence supports this case."
        else:
            evidence_status = "Evidence selected. Review your conclusion before submitting."
        draw_paragraph(screen, evidence_status, SMALL, GOLD, 65, 447, 450, 19)

        submit_rect = pygame.Rect(690, 555, 300, 44)
        ready = (
            len(self.final_evidence_presented) >= 2
            and self.final_suspect is not None
            and self.final_location is not None
        )
        draw_button(screen, submit_rect, "SUBMIT FINAL ACCUSATION  →", mouse_pos, GOLD, ready)
        self.add_button(submit_rect, "SUBMIT ACCUSATION", "solve_final_case", GOLD, ready)

    def solve_final_case(self):
        if len(self.final_evidence_presented) < 2:
            self.notify("Select at least two pieces of supporting evidence.", RED)
            return
        if not self.final_suspect or not self.final_location:
            self.notify("Choose both a suspect and the murder location.", RED)
            return
        is_correct = (
            self.final_suspect == CORRECT_SUSPECT
            and self.final_location == "Secret laboratory"
        )
        if is_correct:
            if 1 not in self.final_evidence_presented or not {
                3, 4, 5
            }.intersection(self.final_evidence_presented):
                self.notify(
                    "Your accusation needs the 10:05 terminal log and another clue linking Victor to the lab.",
                    RED,
                )
                return
            if not self.final_case_solved:
                self.final_best_ending = (
                    len(self.final_evidence_presented) == len(FINAL_CASE_CLUES)
                    and len(self.final_suspects_interviewed) == len(FINAL_SUSPECT_PROFILES)
                    and self.final_timeline_complete
                    and self.quiz_score >= 4
                    and self.secret_door_unlocked
                    and self.password_solved
                )
                self.score += 500 if self.final_best_ending else 250
            self.final_case_solved = True
            self.final_case_ending = "master" if self.final_best_ending else "solved"
            self.final_case_stage = "ending"
            self.notify(
                "The evidence proves Victor Shaw killed Adrian Vale in the secret laboratory.",
                GREEN,
            )
        else:
            self.final_case_ending = "wrong"
            self.notify("That accusation does not fit the evidence. Review the case and try again.", RED)
        self.save_progress()

    def draw_final_ending(self, mouse_pos):
        overlay = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
        overlay.fill((3, 7, 18, 225))
        screen.blit(overlay, (0, 0))
        box = pygame.Rect(175, 140, 750, 440)
        draw_panel(screen, box, (20, 34, 56), GOLD if self.final_case_ending == "master" else CYAN)
        if self.final_case_ending == "wrong":
            heading, color = "WRONG ACCUSATION", RED
            description = (
                "The evidence does not support that conclusion. Your clues, "
                "interviews, and verified timeline are saved—review them and try again."
            )
        elif self.final_case_ending == "master":
            heading, color = "MASTER DETECTIVE", GOLD
            description = (
                "Victor Shaw disabled the terminal, used the hidden passage, "
                "and murdered Adrian Vale in the secret laboratory. You connected every clue."
            )
        else:
            heading, color = "CASE SOLVED", GREEN
            description = (
                "Victor Shaw murdered Adrian Vale in the secret laboratory. "
                "The override log and laboratory evidence exposed his alibi."
            )
        draw_text(screen, heading, BIG, color, 225, 183)
        draw_paragraph(screen, description, FONT, WHITE, 225, 247, 650, 27)
        draw_text(screen, f"FINAL SCORE: {self.score} XP", MEDIUM, GOLD, 225, 365)
        if self.final_case_ending == "wrong":
            rect = pygame.Rect(225, 442, 300, 48)
            draw_button(screen, rect, "REVIEW CASE & RETRY", mouse_pos, CYAN)
            self.add_button(rect, "REVIEW CASE & RETRY", "review_final_case", CYAN)
        else:
            draw_text(screen, "Your case progress is saved. You can return to the menu at any time.", SMALL, MUTED, 225, 415)
            rect = pygame.Rect(225, 478, 245, 48)
            draw_button(screen, rect, "PLAY AGAIN", mouse_pos, GREEN)
            self.add_button(rect, "PLAY AGAIN", "restart", GREEN)

    def interact_final_case(self):
        if self.final_case_stage == "discovery":
            self.discover_body()
        elif self.final_case_stage == "evidence":
            self.investigate_final_clue()

    def draw_final_mystery(self, mouse_pos, dt=0):
        self.draw_final_objective()
        if self.final_case_stage == "ending":
            draw_text(screen, "06  /  CASE CLOSED", BIG, WHITE, 30, 112)
            self.draw_final_ending(mouse_pos)
            return
        if self.final_case_stage in ("discovery", "discovery_dialogue", "evidence"):
            if self.final_case_stage == "discovery":
                draw_text(screen, "06  /  THE BODY IN THE EAST WING", BIG, WHITE, 30, 112)
                draw_text(screen, "Find Dr. Adrian Vale. Approach the body and press E to begin.", FONT, MUTED, 32, 158)
                self.draw_final_room(dt)
            elif self.final_case_stage == "discovery_dialogue":
                draw_text(screen, "06  /  THE BODY IN THE EAST WING", BIG, WHITE, 30, 112)
                self.draw_final_room(0)
                self.draw_final_discovery_dialogue(mouse_pos)
            else:
                self.draw_final_evidence_stage(mouse_pos, dt)
            return
        if self.final_case_stage == "interviews":
            self.draw_final_interviews(mouse_pos)
        elif self.final_case_stage == "timeline":
            self.draw_final_timeline(mouse_pos)
        elif self.final_case_stage == "accusation":
            self.draw_final_accusation(mouse_pos)
            if self.final_case_ending == "wrong":
                self.draw_final_ending(mouse_pos)
        if self.dialogue_open and self.final_case_stage != "interviews":
            self.dialogue_open = False

    def draw_final_objective(self):
        objectives = {
            "discovery": "Find Dr. Vale in the east wing",
            "discovery_dialogue": "Secure all six crime-scene clues",
            "evidence": f"Collect crime-scene clues  {len(self.final_clues_found)} / 6",
            "interviews": f"Record suspect interviews  {len(self.final_suspects_interviewed)} / 4",
            "timeline": "Put the four events in order",
            "accusation": "Choose suspect, location, and clues",
            "ending": "Case closed",
        }
        rect = pygame.Rect(805, 102, 265, 76)
        draw_panel(screen, rect, (17, 27, 48), CYAN)
        draw_text(screen, "CURRENT OBJECTIVE", SMALL, GOLD, 822, 112)
        draw_paragraph(
            screen, objectives.get(self.final_case_stage, "Review the case file."),
            SMALL, WHITE, 822, 137, 225, 19
        )

    def mansion_barriers(self):
        return [
            pygame.Rect(355, 110, 18, 183),
            pygame.Rect(355, 388, 18, 262),
            pygame.Rect(695, 110, 18, 126),
            pygame.Rect(695, 390, 18, 260),
            pygame.Rect(500, 110, 140, 18),
            pygame.Rect(420, 500, 180, 20),
        ]

    def interact_mansion(self):
        position = pygame.Vector2(self.player.center)
        key_pos = pygame.Vector2(245, 220)
        ledger_pos = pygame.Vector2(535, 190)
        door_pos = pygame.Vector2(954, 320)

        if not self.mansion_key_found and position.distance_to(key_pos) < 68:
            self.mansion_key_found = True
            self.score += 100
            self.notify("Keycard recovered from the guest room desk. (+100)", GREEN)
            self.save_progress()
        elif not self.hidden_ledger_found and position.distance_to(ledger_pos) < 72:
            self.hidden_ledger_found = True
            self.score += 100
            self.notify("Hidden ledger found: the east wing was accessed at 10:05 PM. (+100)", GOLD)
            self.save_progress()
        elif position.distance_to(door_pos) < 82:
            if self.mansion_key_found and self.hidden_ledger_found:
                self.mansion_door_unlocked = True
                self.level = 2
                self.unlocked_level = max(self.unlocked_level, 2)
                self.active_suspect = None
                self.notify("Restricted wing unlocked. Begin the interviews.", GREEN)
                self.save_progress()
            elif not self.mansion_key_found:
                self.notify("The restricted-wing door needs a keycard. Search the guest room.", RED)
            else:
                self.notify("The door's security panel references a missing ledger. Search the study.", GOLD)
        else:
            self.notify("Nothing within reach. Search near the desk and study shelves.", MUTED)

    def draw_mansion_level(self, mouse_pos, dt):
        room = pygame.Rect(35, 108, 1030, 542)
        pygame.draw.rect(screen, (26, 30, 48), room, border_radius=14)
        pygame.draw.rect(screen, (48, 43, 59), (45, 118, 1010, 522), border_radius=10)

        # Distinct room rugs make the connected floorplan readable.
        pygame.draw.rect(screen, (60, 39, 55), (58, 135, 284, 490), border_radius=12)
        pygame.draw.rect(screen, (38, 53, 69), (376, 135, 304, 490), border_radius=12)
        pygame.draw.rect(screen, (59, 47, 42), (730, 135, 314, 490), border_radius=12)

        for barrier in self.mansion_barriers():
            pygame.draw.rect(screen, (97, 77, 70), barrier, border_radius=4)
            pygame.draw.rect(screen, (132, 101, 79), barrier, 2, border_radius=4)

        # Furnishings / search spots.
        pygame.draw.rect(screen, (91, 55, 67), (98, 282, 150, 72), border_radius=10)
        pygame.draw.rect(screen, (45, 36, 51), (111, 294, 124, 48), border_radius=8)
        pygame.draw.rect(screen, (108, 75, 53), (178, 183, 102, 38), border_radius=5)
        pygame.draw.rect(screen, (112, 80, 55), (462, 155, 142, 42), border_radius=5)
        pygame.draw.rect(screen, (42, 34, 43), (762, 224, 173, 90), border_radius=9)
        pygame.draw.rect(screen, (102, 73, 56), (796, 420, 138, 48), border_radius=5)

        if not self.mansion_key_found:
            pygame.draw.circle(screen, GOLD, (245, 220), 15, 2)
            pygame.draw.circle(screen, GOLD, (245, 220), 5)
            draw_text(screen, "KEYCARD", SMALL, GOLD, 208, 239)
        else:
            draw_text(screen, "KEYCARD FOUND", SMALL, GREEN, 180, 239)

        if not self.hidden_ledger_found:
            pygame.draw.rect(screen, (173, 126, 85), (515, 173, 38, 25), border_radius=3)
            pygame.draw.line(screen, GOLD, (521, 180), (547, 180), 1)
            pygame.draw.line(screen, GOLD, (521, 187), (543, 187), 1)
            draw_text(screen, "SEARCH DESK", SMALL, GOLD, 491, 205)
        else:
            draw_text(screen, "LEDGER LOGGED", SMALL, GREEN, 493, 205)

        door = pygame.Rect(942, 285, 37, 70)
        pygame.draw.rect(screen, (34, 30, 47), door, border_radius=4)
        pygame.draw.rect(
            screen, GREEN if self.mansion_door_unlocked else RED,
            door, 3, border_radius=4
        )
        pygame.draw.circle(screen, GOLD, (door.right - 8, door.centery), 3)
        draw_text(
            screen, "EAST WING",
            SMALL, GREEN if self.mansion_door_unlocked else RED,
            905, 360
        )

        bounds = pygame.Rect(45, 118, 1010, 522)
        barriers = self.mansion_barriers() + [
            pygame.Rect(95, 275, 156, 15),
            pygame.Rect(95, 350, 156, 15),
            pygame.Rect(170, 178, 115, 13),
            pygame.Rect(460, 150, 145, 13),
            pygame.Rect(760, 215, 178, 14),
            pygame.Rect(800, 412, 138, 14),
        ]
        if not self.mansion_door_unlocked:
            barriers.append(door)
        if not self.notebook_open:
            self.move_player(dt, bounds, barriers)
        self.draw_player()

        position = pygame.Vector2(self.player.center)
        nearby = (
            (not self.mansion_key_found and position.distance_to((245, 220)) < 68)
            or (not self.hidden_ledger_found and position.distance_to((535, 190)) < 72)
            or position.distance_to((954, 320)) < 82
        )
        if nearby:
            prompt_rect = pygame.Rect(320, 584, 390, 34)
            pygame.draw.rect(screen, (8, 14, 27), prompt_rect, border_radius=8)
            pygame.draw.rect(screen, GOLD, prompt_rect, 1, border_radius=8)
            prompt = FONT.render("Press E to search or use the east-wing door", True, WHITE)
            screen.blit(prompt, prompt.get_rect(center=prompt_rect.center))

        tasks = [
            (GREEN if self.mansion_key_found else GOLD,
             "Guest-room keycard recovered" if self.mansion_key_found else "Search the guest-room desk for a keycard"),
            (GREEN if self.hidden_ledger_found else GOLD,
             "Hidden ledger recovered" if self.hidden_ledger_found else "Search the study desk for the access ledger"),
            (GREEN if self.mansion_door_unlocked else CYAN,
             "East wing unlocked" if self.mansion_door_unlocked else "Use both discoveries at the east-wing door"),
        ]
        self.draw_world_sidebar(
            "Mansion Search",
            tasks,
            "Find the keycard and concealed access ledger, then reach the east-wing door.",
            "OPTIONAL XP  +200",
        )

    def draw_level_1(self, mouse_pos):
        draw_text(
            screen, "01  /  CRIME SCENE",
            BIG, WHITE, 30, 112
        )
        draw_text(
            screen, "Work the scene: inspect, photograph, then bag each item.",
            FONT, MUTED, 32, 158
        )

        # Left environment panel
        room = pygame.Rect(30, 205, 490, 420)
        draw_panel(screen, room, (15, 24, 43))

        # Warm crime-scene lighting and marked-off floor.
        pygame.draw.circle(screen, (48, 37, 53), (345, 407), 120)
        pygame.draw.rect(screen, (43, 35, 47), (49, 375, 452, 218), border_radius=8)
        for x in range(65, 500, 42):
            pygame.draw.line(screen, (53, 43, 57), (x, 380), (x - 24, 590), 1)

        # Window and storm
        pygame.draw.rect(
            screen, (20, 39, 68),
            (57, 229, 145, 110), border_radius=8
        )
        pygame.draw.line(
            screen, CYAN, (130, 229), (130, 339), 2
        )
        pygame.draw.line(
            screen, CYAN, (57, 283), (202, 283), 2
        )

        for i in range(6):
            x = 66 + i * 22
            pygame.draw.line(
                screen, (53, 98, 137),
                (x, 239), (x - 12, 269), 1
            )

        draw_text(
            screen, "THE EAST MANSION",
            SMALL, MUTED, 60, 354
        )

        # Desk
        pygame.draw.rect(
            screen, (68, 48, 53),
            (240, 435, 225, 20), border_radius=5
        )
        pygame.draw.rect(
            screen, (43, 34, 43),
            (254, 455, 12, 68), border_radius=3
        )
        pygame.draw.rect(
            screen, (43, 34, 43),
            (438, 455, 12, 68), border_radius=3
        )

        # Evidence objects are deliberately large, labeled hotspots.
        objects = [
            ("WATCH", pygame.Rect(258, 390, 62, 48), 0),
            ("GLASS", pygame.Rect(326, 386, 55, 53), 1),
            ("NOTE", pygame.Rect(388, 390, 62, 48), 2),
            ("PRINT", pygame.Rect(70, 444, 96, 58), 3),
        ]

        for label, rect, index in objects:
            found = index in self.collected_clues
            inspected = index in self.inspected_clues
            color = GREEN if found else GOLD if inspected else CYAN
            hover = rect.collidepoint(mouse_pos)

            if hover and not found:
                pygame.draw.circle(
                    screen, (38, 72, 89), rect.center,
                    max(rect.width, rect.height) // 2 + 9, 2
                )

            pygame.draw.rect(
                screen, (35, 65, 81) if hover else (20, 35, 54),
                rect, border_radius=6
            )
            pygame.draw.rect(
                screen, color, rect, 2 if hover else 1, border_radius=6
            )

            if index == 0:
                pygame.draw.circle(screen, GOLD, rect.center, 13, 3)
                pygame.draw.line(
                    screen, WHITE, rect.center,
                    (rect.centerx + 6, rect.centery - 5), 2
                )
                pygame.draw.line(
                    screen, CYAN, rect.center,
                    (rect.centerx - 5, rect.centery + 4), 2
                )
            elif index == 1:
                pygame.draw.ellipse(
                    screen, (113, 203, 225),
                    (rect.x + 13, rect.y + 6, 26, 20), 2
                )
                pygame.draw.line(
                    screen, CYAN, (rect.centerx, rect.y + 25),
                    (rect.centerx, rect.y + 40), 2
                )
                pygame.draw.line(
                    screen, CYAN, (rect.centerx - 9, rect.y + 40),
                    (rect.centerx + 9, rect.y + 40), 2
                )
            elif index == 2:
                note = pygame.Rect(rect.x + 9, rect.y + 7, 43, 31)
                pygame.draw.rect(screen, (212, 193, 151), note, border_radius=2)
                for line_y in (note.y + 9, note.y + 16, note.y + 23):
                    pygame.draw.line(
                        screen, (91, 78, 66),
                        (note.x + 5, line_y), (note.right - 5, line_y), 1
                    )
            else:
                for offset in (0, 15, 30):
                    pygame.draw.ellipse(
                        screen, (128, 92, 67),
                        (rect.x + 8 + offset, rect.y + 9, 18, 34)
                    )
                    pygame.draw.ellipse(
                        screen, (73, 57, 53),
                        (rect.x + 11 + offset, rect.y + 13, 12, 25)
                    )

            draw_text(
                screen, "BAGGED" if found else label,
                SMALL, color, rect.x, rect.bottom + 4
            )

            self.add_button(
                rect, label, ("clue", index), CYAN
            )

        draw_text(
            screen, "CLICK AN EVIDENCE MARKER TO BEGIN",
            SMALL, GOLD, 60, 573
        )

        # Evidence list
        evidence_rect = pygame.Rect(545, 205, 525, 420)
        draw_panel(screen, evidence_rect)

        draw_text(
            screen, "SCENE OBJECTIVES",
            MEDIUM, WHITE, 568, 226
        )
        draw_text(
            screen,
            f"Evidence bagged: {len(self.collected_clues)} / 4",
            FONT, CYAN, 568, 263
        )
        progress_rect = pygame.Rect(568, 286, 477, 6)
        pygame.draw.rect(screen, BORDER, progress_rect, border_radius=3)
        if self.collected_clues:
            pygame.draw.rect(
                screen, GREEN,
                (progress_rect.x, progress_rect.y,
                 int(progress_rect.width * len(self.collected_clues) / len(CLUES)),
                 progress_rect.height),
                border_radius=3
            )

        y = 308

        for index, clue in enumerate(CLUES):
            found = index in self.collected_clues

            card = pygame.Rect(565, y, 485, 58)
            pygame.draw.rect(
                screen,
                (23, 39, 57) if found else (17, 25, 43),
                card, border_radius=8
            )
            pygame.draw.rect(
                screen,
                GREEN if found else BORDER,
                card, 1, border_radius=8
            )

            title = clue["name"] if found else "Undiscovered evidence"
            steps = (
                ("INSPECTED" if index in self.inspected_clues else "INSPECT")
                + "   ·   "
                + ("PHOTO" if index in self.photographed_clues else "PHOTOGRAPH")
                + "   ·   "
                + ("BAGGED" if found else "BAG")
            )

            draw_text(
                screen, title, FONT,
                GREEN if found else MUTED,
                579, y + 7
            )
            draw_text(
                screen, steps, SMALL,
                GREEN if found else CYAN if index in self.inspected_clues else MUTED,
                579, y + 33
            )
            y += 70

        if self.selected_clue is not None:
            self.draw_evidence_dialogue(mouse_pos)

        if len(self.collected_clues) == 4:
            self.add_button(
                (740, 580, 285, 34),
                "COMPLETE LEVEL 1  →",
                "finish1", GREEN
            )

    def draw_evidence_dialogue(self, mouse_pos):
        index = self.selected_clue
        clue = CLUES[index]
        overlay = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
        overlay.fill((3, 7, 18, 232))
        screen.blit(overlay, (0, 0))

        box = pygame.Rect(160, 125, 780, 465)
        draw_panel(screen, box, (19, 32, 55), CYAN)

        badge = pygame.Rect(195, 153, 48, 32)
        pygame.draw.rect(screen, (71, 48, 112), badge, border_radius=8)
        draw_text(screen, f"0{index + 1}", FONT, WHITE, badge.x + 14, badge.y + 6)
        draw_text(screen, "EVIDENCE RECOVERY  ·  READ THIS, THEN CLICK THE BRIGHT BUTTONS", SMALL, GOLD, 260, 161)
        draw_text(screen, clue["name"], BIG, WHITE, 195, 207)
        pygame.draw.line(screen, (67, 91, 128), (195, 261), (905, 261), 2)

        draw_text(screen, "WHAT YOU FOUND", FONT, GOLD, 195, 281)
        draw_paragraph(
            screen, clue["detail"], FONT, WHITE, 195, 309, 680, 25
        )

        task_label, task_description = SCENE_EXAMS[index]
        if index in self.collected_clues:
            stage_text, next_step = "3 / 3  ·  COMPLETE", "This evidence is safely in your notebook."
        elif index in self.photographed_clues:
            stage_text, next_step = "3 / 3  ·  YOUR TURN: BAG IT", "Click the green BAG EVIDENCE button."
        elif index in self.inspected_clues:
            stage_text, next_step = "2 / 3  ·  YOUR TURN: TAKE A PHOTO", "Click the purple PHOTOGRAPH button."
        else:
            stage_text, next_step = "1 / 3  ·  YOUR TURN: INSPECT IT", task_description
        draw_text(screen, stage_text, MEDIUM, GOLD, 195, 374)
        draw_text(screen, next_step, FONT, WHITE, 195, 402)

        inspect_rect = pygame.Rect(195, 458, 205, 58)
        photo_rect = pygame.Rect(430, 458, 205, 58)
        bag_rect = pygame.Rect(665, 458, 205, 58)
        close_rect = pygame.Rect(804, 536, 78, 34)

        draw_button(
            screen, inspect_rect,
            "1  " + (task_label if index not in self.inspected_clues else "DONE ✓"),
            mouse_pos, CYAN, index not in self.inspected_clues
        )
        draw_button(
            screen, photo_rect,
            "2  " + ("PHOTOGRAPH" if index not in self.photographed_clues else "PHOTO ✓"),
            mouse_pos, PURPLE,
            index in self.inspected_clues and index not in self.photographed_clues
        )
        draw_button(
            screen, bag_rect,
            "3  " + ("BAG EVIDENCE" if index not in self.collected_clues else "BAGGED ✓"),
            mouse_pos, GREEN,
            index in self.photographed_clues and index not in self.collected_clues
        )
        draw_button(screen, close_rect, "CLOSE", mouse_pos, GOLD)

        self.add_button(
            inspect_rect, "INSPECT", ("scene_action", ("inspect", index)),
            CYAN, index not in self.inspected_clues
        )
        self.add_button(
            photo_rect, "PHOTOGRAPH", ("scene_action", ("photograph", index)),
            PURPLE,
            index in self.inspected_clues and index not in self.photographed_clues
        )
        self.add_button(
            bag_rect, "BAG EVIDENCE", ("scene_action", ("bag", index)),
            GREEN,
            index in self.photographed_clues and index not in self.collected_clues
        )
        self.add_button(close_rect, "CLOSE", "close_evidence", GOLD)

    def draw_first_time_guide(self, mouse_pos):
        overlay = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
        overlay.fill((3, 7, 18, 225))
        screen.blit(overlay, (0, 0))

        panel = pygame.Rect(205, 125, 690, 470)
        draw_panel(screen, panel, (21, 34, 59), CYAN)
        draw_text(screen, "WELCOME, DETECTIVE", SMALL, GOLD, 250, 160)
        draw_text(screen, "Six challenges. One final deduction.", BIG, WHITE, 250, 190)
        draw_text(
            screen, "Follow the on-screen objectives. Your progress saves automatically.",
            FONT, (224, 234, 249), 252, 250
        )

        instructions = [
            ("1", "FOUR KEYS", "Explore the rooms. Walk near each glowing key and press E."),
            ("2", "JUMBLED MESSAGE", "Type each shuffled word and press Enter within 30 seconds."),
            ("3", "SECRET DOOR", "Reveal symbols with F/E, enter their order, take the hidden key, then find the moon door."),
            ("4", "PASSWORD VAULT", "Enter the four-digit time code from the security log."),
            ("5", "APTITUDE TEST", "Choose an answer and read the explanation after each question."),
            ("6", "FINAL MYSTERY", "Present evidence, then choose both the killer and location."),
        ]
        for index, (number, title, description) in enumerate(instructions):
            y = 280 + index * 39
            badge = pygame.Rect(252, y, 30, 30)
            pygame.draw.rect(screen, (69, 47, 109), badge, border_radius=9)
            pygame.draw.rect(screen, PURPLE, badge, 1, border_radius=9)
            numeral = SMALL.render(number, True, WHITE)
            screen.blit(numeral, numeral.get_rect(center=badge.center))
            draw_text(screen, title, SMALL, CYAN, 294, y + 2)
            draw_text(screen, description, SMALL, WHITE, 450, y + 2)

        start_rect = pygame.Rect(430, 535, 240, 42)
        draw_button(screen, start_rect, "GOT IT — START", mouse_pos, GREEN)
        self.add_button(start_rect, "START", "start_tutorial", GREEN)

    def close_first_time_guide(self):
        self.tutorial_open = False
        self.tutorial_seen = True
        self.save_progress()

    def inspect_clue(self, index):
        if index in self.inspected_clues:
            self.notify(
                f"You already inspected: {CLUES[index]['name']}",
                GOLD
            )
            return

        self.inspected_clues.add(index)
        self.score += 25
        self.notify(
            f"Inspection recorded: {CLUES[index]['name']} (+25). Photograph it next.",
            CYAN
        )
        self.save_progress()

    def photograph_clue(self, index):
        if index not in self.inspected_clues:
            self.notify("Inspect the evidence before photographing it.", GOLD)
            return
        if index in self.photographed_clues:
            self.notify("Photo already logged. Bag the evidence next.", GOLD)
            return

        self.photographed_clues.add(index)
        self.score += 25
        self.notify(
            f"Photo logged: {CLUES[index]['name']} (+25). Bag it to secure the clue.",
            PURPLE
        )
        self.save_progress()

    def bag_clue(self, index):
        if index not in self.photographed_clues:
            self.notify("Photograph the evidence before bagging it.", GOLD)
            return
        if index in self.collected_clues:
            self.notify(f"{CLUES[index]['name']} is already secured.", GOLD)
            return

        self.collected_clues.add(index)
        self.score += 50
        self.notify(
            f"Evidence secured: {CLUES[index]['name']} (+50).",
            GREEN
        )
        self.save_progress()

    # --------------------------------------------------
    # LEVEL 2 - SUSPECT INTERROGATION
    # --------------------------------------------------

    def draw_level_2(self, mouse_pos):
        draw_text(
            screen, "03  /  SUSPECT INTERROGATION",
            BIG, WHITE, 30, 112
        )
        draw_text(
            screen, "Every suspect has a motive. Find the contradiction.",
            FONT, MUTED, 32, 158
        )

        # Suspect cards
        positions = [
            (30, 215), (560, 215),
            (30, 415), (560, 415)
        ]

        for index, suspect in enumerate(SUSPECTS):
            x, y = positions[index]
            rect = pygame.Rect(x, y, 510, 175)
            draw_panel(screen, rect)

            selected = self.active_suspect == index
            accent = GOLD if selected else PURPLE

            draw_text(
                screen, suspect["name"],
                MEDIUM, WHITE, x + 18, y + 15
            )
            draw_text(
                screen, suspect["role"],
                SMALL, CYAN, x + 18, y + 48
            )
            draw_text(
                screen, "MOTIVE",
                SMALL, GOLD, x + 18, y + 78
            )
            draw_text(
                screen, suspect["motive"],
                FONT, MUTED, x + 90, y + 76
            )

            draw_text(
                screen, "ALIBI",
                SMALL, GOLD, x + 18, y + 108
            )
            draw_paragraph(
                screen, suspect["alibi"],
                SMALL, MUTED, x + 75, y + 107, 405, 19
            )

            button_rect = pygame.Rect(x + 18, y + 137, 205, 29)

            label = (
                "REVIEWED ✓" if index in self.asked_suspects
                else "INTERROGATE SUSPECT"
            )

            draw_button(
                screen, button_rect, label,
                mouse_pos, accent
            )

            self.add_button(
                button_rect, label, ("suspect", index), accent
            )

        if len(self.asked_suspects) == 4:
            rect = pygame.Rect(755, 617, 280, 30)
            draw_button(
                screen, rect,
                "COMPLETE INTERROGATION  →",
                mouse_pos, GREEN
            )
            self.add_button(
                rect, "COMPLETE INTERROGATION  →",
                "finish2", GREEN
            )

        if self.dialogue_open:
            self.draw_suspect_dialogue()

    def draw_suspect_dialogue(self):
        suspect = SUSPECTS[self.active_suspect]
        overlay = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
        overlay.fill((3, 7, 18, 205))
        screen.blit(overlay, (0, 0))

        box = pygame.Rect(185, 170, 730, 410)
        draw_panel(screen, box, (17, 27, 47), CYAN)

        draw_text(screen, "INTERROGATION TRANSCRIPT", SMALL, GOLD, 220, 202)
        draw_text(screen, suspect["name"], BIG, WHITE, 220, 230)
        draw_text(screen, suspect["role"], SMALL, CYAN, 222, 278)

        pygame.draw.line(screen, BORDER, (220, 310), (875, 310), 1)
        draw_text(screen, "YOUR QUESTION", SMALL, GOLD, 220, 330)
        draw_paragraph(
            screen, suspect["question"],
            FONT, WHITE, 220, 353, 640, 24
        )

        draw_text(screen, "THEIR ANSWER", SMALL, GOLD, 220, 405)
        draw_paragraph(
            screen, suspect["answer"],
            FONT, CYAN, 220, 429, 640, 24
        )

        draw_button(
            screen, self.dialogue_close_rect, "CLOSE",
            pygame.mouse.get_pos(), CYAN
        )

    def interrogate(self, index):
        suspect = SUSPECTS[index]
        self.active_suspect = index
        self.dialogue_open = True

        if index not in self.asked_suspects:
            self.asked_suspects.add(index)
            self.score += 50
            self.save_progress()

        if suspect["name"] == "Victor Shaw":
            if not self.revealed_contradiction:
                self.revealed_contradiction = True
                self.score += 50
                self.notify(
                    "Contradiction found! The east-wing security "
                    "log was disabled at 10:05 PM.",
                    GOLD
                )
            else:
                self.notify(
                    f"{suspect['name']}: {suspect['answer']}",
                    CYAN
                )
        else:
            self.notify(
                f"{suspect['name']}: {suspect['answer']}",
                CYAN
            )

    # --------------------------------------------------
    # LEVEL 3 - SECRET LABORATORY
    # --------------------------------------------------

    def draw_level_3(self, mouse_pos):
        draw_text(
            screen, "04  /  THE PASSWORD VAULT",
            BIG, WHITE, 30, 112
        )
        draw_text(
            screen, "Enter the four-digit time code from the security log. Three errors cause a lockout.",
            FONT, MUTED, 32, 158
        )

        # Laboratory environment
        lab_rect = pygame.Rect(30, 205, 500, 415)
        draw_panel(screen, lab_rect, (12, 26, 43))

        draw_text(
            screen, "RESTRICTED ACCESS",
            MEDIUM, CYAN, 57, 230
        )

        # Decorative lab containers
        for i in range(4):
            x = 65 + i * 105
            pygame.draw.rect(
                screen, (22, 40, 61),
                (x, 300, 60, 90), border_radius=8
            )
            pygame.draw.rect(
                screen, PURPLE if i % 2 == 0 else CYAN,
                (x + 10, 328, 40, 52),
                2, border_radius=5
            )
            pygame.draw.circle(
                screen,
                PURPLE if i % 2 == 0 else CYAN,
                (x + 30, 350), 6
            )

        # Terminal
        terminal = pygame.Rect(75, 425, 390, 140)
        pygame.draw.rect(
            screen, (5, 13, 26), terminal, border_radius=10
        )
        pygame.draw.rect(
            screen, CYAN, terminal, 2, border_radius=10
        )

        draw_text(
            screen, "VALE RESEARCH SYSTEM",
            SMALL, CYAN, 95, 442
        )

        shown_password = (
            self.password if self.password
            else "TYPE PASSWORD HERE"
        )
        draw_text(
            screen, shown_password,
            MEDIUM, WHITE, 95, 476
        )

        draw_text(
            screen, "Press ENTER to submit",
            SMALL, MUTED, 95, 526
        )

        # Puzzle information
        puzzle = pygame.Rect(555, 205, 515, 415)
        draw_panel(screen, puzzle)

        draw_text(
            screen, "ENCRYPTED RESEARCH NOTE",
            MEDIUM, WHITE, 580, 229
        )

        draw_paragraph(
            screen,
            "The terminal requires a four-digit time code. "
            "Enter the log time as HHMM, without punctuation.",
            FONT, MUTED, 580, 273, 455
        )

        draw_text(
            screen, "CLUE 01",
            SMALL, GOLD, 580, 340
        )
        draw_paragraph(
            screen,
            "The east-wing security log was disabled at 10:05 PM.",
            FONT, WHITE, 580, 365, 440
        )

        draw_text(
            screen, "CLUE 02",
            SMALL, GOLD, 580, 420
        )
        draw_paragraph(
            screen,
            "Type the time as four digits. Example format: HHMM.",
            FONT, WHITE, 580, 445, 440
        )

        remaining_lockout = max(
            0, (self.vault_locked_until - pygame.time.get_ticks() + 999) // 1000
        )
        if self.password_solved:
            draw_text(
                screen, "ACCESS GRANTED ✓",
                MEDIUM, GREEN, 580, 535
            )
            continue_rect = pygame.Rect(580, 572, 450, 42)
            draw_button(
                screen, continue_rect, "CONTINUE TO LEVEL 5  →",
                mouse_pos, GREEN,
            )
            self.add_button(
                continue_rect, "CONTINUE TO LEVEL 5",
                "finish3", GREEN
            )
        elif remaining_lockout:
            draw_text(
                screen, f"VAULT LOCKED  ·  {remaining_lockout}s",
                MEDIUM, RED, 580, 535
            )
        else:
            draw_text(
                screen, f"PASSWORD REQUIRED  ·  FAILED ATTEMPTS {self.vault_failures}/3",
                SMALL, GOLD, 580, 535
            )

            self.add_button(
                (580, 575, 180, 32),
                "CLEAR PASSWORD",
                "clear_password", RED
            )

    def submit_password(self):
        now = pygame.time.get_ticks()
        if now < self.vault_locked_until:
            remaining = max(1, (self.vault_locked_until - now + 999) // 1000)
            self.notify(f"Security lockout. Try again in {remaining} seconds.", RED)
            return
        if self.password.strip().upper() == CORRECT_PASSWORD:
            if not self.password_solved:
                self.score += 300

            self.password_solved = True
            self.notify(
                "Access granted! Research file unlocked. (+300)",
                GREEN
            )
            self.save_progress()
        else:
            self.notify(
                "Incorrect password. Re-examine the clues.",
                RED
            )
            self.password = ""
            self.vault_failures += 1
            if self.vault_failures >= 3:
                self.vault_failures = 0
                self.vault_locked_until = now + 10_000
                self.notify("Three failed attempts. Vault locked for 10 seconds.", RED)
            self.save_progress()

    # --------------------------------------------------
    # LEVEL 4 - EVIDENCE BOARD
    # --------------------------------------------------

    def draw_level_4(self, mouse_pos):
        draw_text(
            screen, "05  /  EVIDENCE BOARD",
            BIG, WHITE, 30, 112
        )
        draw_text(
            screen, "Review the case and identify the killer.",
            FONT, MUTED, 32, 158
        )

        # Timeline panel
        left = pygame.Rect(30, 205, 500, 420)
        draw_panel(screen, left)

        draw_text(
            screen, "MURDER TIMELINE",
            MEDIUM, WHITE, 55, 228
        )

        timeline = [
            ("10:05 PM", "East-wing security log disabled"),
            ("10:15 PM", "Victim's watch stopped"),
            ("UNKNOWN", "Victim found dead"),
            ("AFTER", "Research terminal investigated"),
        ]

        y = 287

        for time, event in timeline:
            pygame.draw.circle(
                screen, CYAN, (70, y + 9), 5
            )
            pygame.draw.line(
                screen, BORDER,
                (70, y + 18), (70, y + 53), 2
            )

            draw_text(
                screen, time, SMALL, GOLD, 90, y
            )
            draw_text(
                screen, event, FONT, WHITE, 90, y + 21
            )
            y += 75

        # Deduction panel
        right = pygame.Rect(555, 205, 515, 420)
        draw_panel(screen, right)

        draw_text(
            screen, "FINAL DEDUCTION",
            MEDIUM, WHITE, 580, 228
        )

        draw_paragraph(
            screen,
            "Who had the ability to disable the security log "
            "before the victim's watch stopped?",
            FONT, MUTED, 580, 270, 455
        )

        draw_text(
            screen, "SELECT YOUR ACCUSATION",
            SMALL, GOLD, 580, 340
        )

        positions = [
            (580, 375), (815, 375),
            (580, 425), (815, 425),
        ]

        for index, suspect in enumerate(SUSPECTS):
            x, y = positions[index]
            rect = pygame.Rect(x, y, 220, 38)

            selected = self.accusation == suspect["name"]

            draw_button(
                screen, rect, suspect["name"],
                mouse_pos,
                GREEN if selected else PURPLE
            )

            self.add_button(
                rect, suspect["name"],
                ("accuse", suspect["name"]),
                GREEN if selected else PURPLE
            )

        if self.accusation:
            draw_text(
                screen, f"Selected: {self.accusation}",
                SMALL, CYAN, 580, 490
            )

            self.add_button(
                (580, 535, 440, 43),
                "LOCK IN YOUR ACCUSATION  →",
                "submit_accusation", GOLD
            )

        if self.ending:
            self.draw_ending()

    def draw_level_5(self, mouse_pos):
        draw_text(
            screen, "06  /  FINAL CONFRONTATION",
            BIG, WHITE, 30, 112
        )
        draw_text(
            screen, "Present evidence. Make the suspect answer for it.",
            FONT, MUTED, 32, 158
        )

        left = pygame.Rect(30, 205, 500, 420)
        draw_panel(screen, left, (16, 25, 42))
        draw_text(screen, "EAST-WING SECURITY ROOM", MEDIUM, CYAN, 55, 230)

        # A stylized suspect silhouette and interrogation table.
        pygame.draw.circle(screen, (174, 132, 115), (276, 350), 39)
        pygame.draw.rect(
            screen, (53, 44, 71), (220, 390, 112, 115),
            border_radius=28
        )
        pygame.draw.rect(
            screen, (103, 65, 62), (102, 500, 350, 25),
            border_radius=7
        )
        pygame.draw.rect(
            screen, (65, 47, 62), (125, 525, 15, 55), border_radius=4
        )
        pygame.draw.rect(
            screen, (65, 47, 62), (413, 525, 15, 55), border_radius=4
        )
        quote = (
            "“I was watching the front entrance.”"
            if not self.final_evidence_presented
            else "“That log should never have been disabled...”"
        )
        draw_paragraph(screen, quote, FONT, WHITE, 80, 558, 405, 23)

        right = pygame.Rect(555, 205, 515, 420)
        draw_panel(screen, right)
        draw_text(screen, "PRESENT YOUR EVIDENCE", MEDIUM, WHITE, 580, 229)
        draw_paragraph(
            screen,
            "Choose evidence from your notebook to challenge Victor's alibi. "
            "Present at least two pieces to force a response.",
            SMALL, MUTED, 580, 270, 450, 20
        )

        positions = [(580, 345), (810, 345), (580, 397), (810, 397)]
        for index, clue in enumerate(CLUES):
            x, y = positions[index]
            rect = pygame.Rect(x, y, 215, 42)
            already_presented = index in self.final_evidence_presented
            available = index in self.collected_clues
            accent = GREEN if already_presented else CYAN if available else BORDER
            label = (
                f"{clue['name']}  ✓" if already_presented
                else clue["name"] if available
                else "Evidence not collected"
            )
            draw_button(
                screen, rect, label, mouse_pos, accent,
                available and not already_presented
            )
            self.add_button(
                rect, label, ("present_evidence", index), accent,
                available and not already_presented
            )

        draw_text(
            screen,
            f"Evidence presented: {len(self.final_evidence_presented)} / 4",
            FONT, GOLD, 580, 470
        )
        if len(self.final_evidence_presented) >= 2:
            challenge_rect = pygame.Rect(580, 515, 445, 48)
            draw_button(
                screen, challenge_rect, "CHALLENGE VICTOR'S ALIBI",
                mouse_pos, GOLD
            )
            self.add_button(
                challenge_rect, "CHALLENGE VICTOR",
                "final_confrontation", GOLD
            )

        if self.ending:
            self.draw_ending()

    def submit_accusation(self):
        if not self.accusation:
            self.notify("Select a suspect first.", RED)
            return

        if self.accusation == CORRECT_SUSPECT:
            self.level = 5
            self.unlocked_level = 5
            self.ending = None
            self.confrontation_complete = False
            self.notify(
                "Victor is your prime suspect. Confront him with evidence.",
                GREEN
            )
            self.save_progress()
        elif self.accusation == "Dr. Evelyn Reed":
            self.ending = "wrong_evelyn"
            self.notify(
                "The evidence does not support this accusation.",
                RED
            )
        else:
            self.ending = "wrong"
            self.notify(
                "Wrong accusation. Review the evidence.",
                RED
            )

    def present_final_evidence(self, index):
        if index not in self.collected_clues:
            self.notify("You cannot present evidence you did not secure.", RED)
            return
        if index in self.final_evidence_presented:
            self.notify("That evidence has already been presented.", GOLD)
            return

        self.final_evidence_presented.add(index)
        self.score += 50
        self.notify(
            f"Presented {CLUES[index]['name']}. Watch Victor's reaction.",
            CYAN
        )
        self.save_progress()

    def resolve_confrontation(self):
        if self.confrontation_complete:
            self.notify("This case has already been solved. Start a new case to replay.", GOLD)
            return
        if len(self.final_evidence_presented) < 2:
            self.notify("Present at least two pieces of evidence first.", RED)
            return
        if self.accusation != CORRECT_SUSPECT:
            self.notify("You have not identified the right suspect yet.", RED)
            return

        self.confrontation_complete = True
        if (
            len(self.final_evidence_presented) == len(CLUES)
            and self.revealed_contradiction
            and self.password_solved
            and self.hidden_ledger_found
        ):
            self.ending = "perfect"
            self.score += 500
        elif len(self.final_evidence_presented) >= 2:
            self.ending = "correct"
            self.score += 250
        self.notify("Victor's alibi collapses. The case is solved.", GREEN)
        self.save_progress()

    def draw_ending(self):
        overlay = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
        overlay.fill((3, 7, 18, 225))
        screen.blit(overlay, (0, 0))

        box = pygame.Rect(225, 200, 650, 330)
        draw_panel(screen, box, (18, 29, 50), PURPLE)

        if self.ending == "perfect":
            heading = "MASTER DETECTIVE"
            description = (
                "You connected the timeline, uncovered the "
                "security contradiction, and solved the case."
            )
            color = GOLD
        elif self.ending == "correct":
            heading = "CASE SOLVED"
            description = (
                "You identified Victor Shaw, but some "
                "evidence remains unexplored."
            )
            color = GREEN
        elif self.ending == "wrong_evelyn":
            heading = "THE CASE REMAINS OPEN"
            description = (
                "Evelyn had a motive, but motive alone is not "
                "proof. Reconsider the security evidence."
            )
            color = RED
        else:
            heading = "INCORRECT ACCUSATION"
            description = (
                "Your evidence does not support this suspect. "
                "Return to the board and try again."
            )
            color = RED

        draw_text(
            screen, heading, BIG, color, 275, 235
        )

        draw_paragraph(
            screen, description,
            FONT, WHITE, 275, 300, 540, 28
        )

        draw_text(
            screen, f"FINAL SCORE: {self.score}",
            MEDIUM, GOLD, 275, 380
        )

        if self.ending in ("wrong", "wrong_evelyn"):
            self.add_button(
                (275, 445, 250, 45),
                "TRY ANOTHER SUSPECT",
                "close_ending", CYAN
            )
        else:
            self.add_button(
                (275, 445, 250, 45),
                "PLAY AGAIN",
                "restart", GREEN
            )

    # --------------------------------------------------
    # NOTEBOOK
    # --------------------------------------------------

    def draw_notebook(self):
        overlay = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
        overlay.fill((3, 7, 18, 220))
        screen.blit(overlay, (0, 0))

        box = pygame.Rect(175, 125, 750, 490)
        draw_panel(screen, box, (17, 27, 47), CYAN)

        draw_text(
            screen, "DETECTIVE NOTEBOOK",
            BIG, WHITE, 210, 155
        )

        draw_text(
            screen,
            f"Score: {self.score} XP",
            FONT, GOLD, 215, 215
        )

        if self.level == 5:
            draw_text(
                screen,
                f"Final-case evidence: {len(self.final_clues_found)} / {len(FINAL_CASE_CLUES)}",
                FONT, CYAN, 215, 250
            )
            y = 285
            if not self.body_discovered:
                draw_text(screen, "Dr. Vale has not yet been discovered.", SMALL, MUTED, 215, y)
                y += 30
            for index in sorted(self.final_clues_found):
                clue = FINAL_CASE_CLUES[index]
                draw_text(screen, clue["name"], SMALL, GREEN, 215, y)
                y = draw_paragraph(
                    screen, clue["detail"], SMALL, MUTED,
                    365, y, 520, 19
                ) + 5
            if self.final_suspects_interviewed:
                names = ", ".join(
                    FINAL_SUSPECT_PROFILES[index]["name"]
                    for index in sorted(self.final_suspects_interviewed)
                )
                y = draw_paragraph(
                    screen, f"Interviews: {names}", SMALL, CYAN, 215,
                    min(y + 4, 560), 640, 19
                ) + 4
            if self.final_timeline_complete:
                draw_text(
                    screen, "Timeline verified: override → passage → attack → escape.",
                    SMALL, GOLD, 215, min(y, 575)
                )
            self.add_button(
                (750, 550, 140, 40),
                "CLOSE",
                "notebook", CYAN
            )
            return

        draw_text(
            screen,
            f"Collected clues: {len(self.collected_clues)} / 4",
            FONT, CYAN, 215, 250
        )

        y = 295

        for index in sorted(self.collected_clues):
            clue = CLUES[index]

            draw_text(
                screen, f"• {clue['name']}",
                FONT, GREEN, 215, y
            )

            y = draw_paragraph(
                screen, clue["detail"],
                SMALL, MUTED, 235, y + 25, 640, 19
            ) + 12

        if self.revealed_contradiction:
            draw_text(
                screen,
                "Contradiction: security log disabled at 10:05 PM.",
                SMALL, GOLD, 215, min(y + 8, 550)
            )

        self.add_button(
            (750, 550, 140, 40),
            "CLOSE",
            "notebook", CYAN
        )

    # --------------------------------------------------
    # BUTTON ACTIONS
    # --------------------------------------------------

    def handle_action(self, action):
        if action == "notebook":
            self.notebook_open = not self.notebook_open
            return

        if action == "resume":
            self.paused = False
            return

        if action == "start_tutorial":
            self.close_first_time_guide()
            return

        if action == "pause_menu":
            self.save_progress()
            self.running = False
            return

        if action == "hint":
            self.use_hint()
            return

        if action == "close_dialogue":
            self.dialogue_open = False
            return

        if action == "close_evidence":
            self.selected_clue = None
            return

        if action == "restart":
            try:
                os.remove(self.save_path)
            except FileNotFoundError:
                pass
            except OSError as error:
                print(f"Could not clear Mind Maze save: {error}")
            self.__init__()
            return

        if action == "close_ending":
            self.ending = None
            self.accusation = None
            return

        if action == "submit_jumble":
            self.submit_jumble()
            return

        if action == "finish_keys":
            if len(self.keys_collected) == len(KEY_LOCATIONS):
                self.level = 1
                self.unlocked_level = max(self.unlocked_level, 1)
                self.notify("All four keys secured. Decode the message they revealed.", GREEN)
                self.save_progress()
            return

        if action == "finish_jumble":
            if self.jumble_index >= len(WORD_PUZZLES):
                self.level = 2
                self.unlocked_level = max(self.unlocked_level, 2)
                self.player.topleft = (95, 570)
                self.notify("The message points to the moon portrait. Search the corridor.", GREEN)
                self.save_progress()
            return

        if action == "clear_symbols":
            self.secret_door_code.clear()
            self.notify("Symbol sequence cleared.", CYAN)
            self.save_progress()
            return

        if action == "next_aptitude":
            self.advance_aptitude_question()
            return

        if action == "solve_final_case":
            self.solve_final_case()
            return

        if action == "begin_final_case":
            self.begin_final_case()
            return

        if action == "continue_final_discovery":
            if self.body_discovered:
                self.final_case_stage = "evidence"
                self.player.topleft = (840, 520)
                self.notify("Crime-scene investigation: collect all six glowing clues with E.", CYAN)
                self.save_progress()
            return

        if action == "final_to_interviews":
            if len(self.final_clues_found) == len(FINAL_CASE_CLUES):
                self.final_case_stage = "interviews"
                self.notify("Six clues secured. Question all four suspects.", GOLD)
                self.save_progress()
            return

        if action == "final_to_timeline":
            if len(self.final_suspects_interviewed) == len(FINAL_SUSPECT_PROFILES):
                self.final_case_stage = "timeline"
                self.notify("All interviews recorded. Place the four events in order.", GOLD)
                self.save_progress()
            return

        if action == "timeline_undo":
            if self.final_timeline_order:
                self.final_timeline_order.pop()
                self.final_timeline_feedback = ""
                self.save_progress()
            return

        if action == "validate_final_timeline":
            if not self.final_timeline_complete:
                self.validate_final_timeline()
            return

        if action == "review_final_case":
            if self.final_case_ending == "wrong":
                self.final_case_ending = None
                self.final_suspect = None
                self.final_location = None
                self.notify("Review the evidence and make a new accusation. Your progress is intact.", CYAN)
                self.save_progress()
            return

        if isinstance(action, tuple):
            kind, value = action

            if kind == "secret_symbol":
                self.record_secret_symbol(value)

            elif kind == "aptitude_answer":
                self.answer_aptitude_question(value)

            elif kind == "open_final_interview":
                self.open_final_interview(value)

            elif kind == "record_final_interview":
                if value not in self.final_suspects_interviewed:
                    self.final_suspects_interviewed.add(value)
                    self.score += 50
                    self.notify(
                        f"{FINAL_SUSPECT_PROFILES[value]['name']} interview recorded. (+50 XP)",
                        GREEN,
                    )
                    self.save_progress()
                self.dialogue_open = False

            elif kind == "timeline_event":
                valid_event_ids = {event["id"] for event in FINAL_TIMELINE_EVENTS}
                if (
                    value in valid_event_ids
                    and value not in self.final_timeline_order
                    and len(self.final_timeline_order) < len(FINAL_TIMELINE_EVENTS)
                ):
                    self.final_timeline_order.append(value)
                    self.final_timeline_feedback = ""
                    self.save_progress()

            elif kind == "final_case_evidence":
                if value in self.final_evidence_presented:
                    self.final_evidence_presented.remove(value)
                else:
                    self.final_evidence_presented.add(value)
                self.save_progress()

            elif kind == "final_evidence":
                if value not in self.collected_clues:
                    self.notify("Find this evidence before presenting it.", GOLD)
                elif value in self.final_evidence_presented:
                    self.final_evidence_presented.remove(value)
                    self.notify(f"{CLUES[value]['name']} withdrawn from the case.", CYAN)
                else:
                    self.final_evidence_presented.add(value)
                    self.notify(f"{CLUES[value]['name']} presented.", GREEN)
                self.save_progress()

            elif kind == "final_suspect":
                self.final_suspect = value
                self.notify(f"Suspect selected: {value}. Choose the location too.", GOLD)
                self.save_progress()

            elif kind == "final_location":
                self.final_location = value
                self.notify(f"Location selected: {value}.", GOLD)
                self.save_progress()

            if kind == "clue":
                self.selected_clue = value
                self.notify(
                    f"Evidence located: {CLUES[value]['name']}. Follow the field protocol.",
                    CYAN
                )

            elif kind == "scene_action":
                task, clue_index = value
                if task == "inspect":
                    self.inspect_clue(clue_index)
                elif task == "photograph":
                    self.photograph_clue(clue_index)
                elif task == "bag":
                    self.bag_clue(clue_index)

            elif kind == "present_evidence":
                self.present_final_evidence(value)

            elif kind == "suspect":
                self.interrogate(value)

            elif kind == "accuse":
                self.accusation = value
                self.notify(
                    f"You selected {value}. Submit when ready.",
                    GOLD
                )

            return

        if action == "finish3":
            if self.password_solved:
                self.level = 4
                self.unlocked_level = max(self.unlocked_level, 4)
                self.notify(
                    "Vault opened. Complete the detective aptitude assessment.",
                    GREEN
                )
                self.save_progress()

        elif action == "clear_password":
            self.password = ""
            self.notify("Password cleared.", CYAN)

        elif action == "submit_accusation":
            self.submit_accusation()

        elif action == "final_confrontation":
            self.resolve_confrontation()

    def draw_pause_menu(self, mouse_pos):
        overlay = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
        overlay.fill((3, 7, 18, 220))
        screen.blit(overlay, (0, 0))
        panel = pygame.Rect(340, 205, 420, 300)
        draw_panel(screen, panel, (17, 27, 47), CYAN)
        title = BIG.render("PAUSED", True, WHITE)
        screen.blit(title, title.get_rect(center=(WIDTH // 2, 260)))

        resume = pygame.Rect(390, 325, 320, 52)
        save_menu = pygame.Rect(390, 395, 320, 48)
        draw_button(screen, resume, "RESUME CASE", mouse_pos, CYAN)
        draw_button(screen, save_menu, "SAVE & RETURN TO MENU", mouse_pos, PURPLE)
        self.add_button(resume, "RESUME", "resume", CYAN)
        self.add_button(save_menu, "SAVE & RETURN", "pause_menu", PURPLE)

    # --------------------------------------------------
    # MAIN LOOP
    # --------------------------------------------------

    def run(self):
        return_to_menu = True

        while self.running:
            dt = min(clock.tick(FPS) / 1000, 0.05)
            ticks = pygame.time.get_ticks()
            mouse_pos = pygame.mouse.get_pos()

            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    self.running = False
                    return_to_menu = False

                elif event.type == pygame.KEYDOWN:
                    if self.tutorial_open:
                        if event.key in (pygame.K_RETURN, pygame.K_SPACE):
                            self.close_first_time_guide()
                        elif event.key == pygame.K_ESCAPE:
                            self.close_first_time_guide()
                        continue

                    if event.key == pygame.K_ESCAPE:
                        if self.paused:
                            self.paused = False
                        elif self.dialogue_open:
                            self.dialogue_open = False
                        elif self.selected_clue is not None:
                            self.selected_clue = None
                        elif self.notebook_open:
                            self.notebook_open = False
                        else:
                            self.save_progress()
                            self.running = False

                    elif event.key == pygame.K_p and not self.notebook_open:
                        self.paused = not self.paused

                    elif event.key == pygame.K_F1 and not self.paused:
                        self.tutorial_open = True

                    elif (
                        self.level == 1
                        and not self.notebook_open
                        and not self.paused
                        and self.jumble_index < len(WORD_PUZZLES)
                        and event.unicode.isalpha()
                    ):
                        answer_length = len(
                            WORD_PUZZLES[self.jumble_index][1]
                        )
                        if len(self.jumble_answer) < answer_length:
                            self.jumble_answer += event.unicode.upper()

                    elif (
                        event.key == pygame.K_n
                        and not self.paused
                        and not self.dialogue_open
                        and self.selected_clue is None
                    ):
                        self.notebook_open = not self.notebook_open

                    elif event.key == pygame.K_h and not self.notebook_open:
                        self.use_hint()

                    elif (
                        event.key == pygame.K_e
                        and not self.notebook_open
                        and not self.paused
                        and self.selected_clue is None
                        and not self.dialogue_open
                    ):
                        if self.level == 0:
                            self.collect_nearby_key()
                        elif self.level == 2:
                            self.interact_secret_room()
                        elif self.level == 5:
                            self.interact_final_case()

                    elif (
                        self.level == 1
                        and not self.notebook_open
                        and not self.paused
                    ):
                        if self.jumble_index < len(WORD_PUZZLES):
                            if event.key == pygame.K_RETURN:
                                self.submit_jumble()
                            elif event.key == pygame.K_BACKSPACE:
                                self.jumble_answer = self.jumble_answer[:-1]

                    elif (
                        self.level == 2
                        and event.key == pygame.K_f
                        and not self.notebook_open
                        and not self.paused
                    ):
                        self.update_flashlight()
                        if self.flashlight_energy > 0:
                            self.flashlight_on = not self.flashlight_on
                            self.notify(
                                "Flashlight on." if self.flashlight_on else "Flashlight off; battery recharging.",
                                CYAN
                            )

                    elif (
                        self.level == 3
                        and not self.notebook_open
                        and not self.paused
                    ):
                        if event.key == pygame.K_RETURN:
                            self.submit_password()
                        elif event.key == pygame.K_BACKSPACE:
                            self.password = self.password[:-1]
                        elif event.unicode.isdecimal() and pygame.time.get_ticks() >= self.vault_locked_until:
                            if len(self.password) < 4:
                                self.password += event.unicode

                elif event.type == pygame.MOUSEBUTTONDOWN:
                    if event.button == 1:
                        if self.tutorial_open:
                            for button in reversed(self.buttons):
                                if button["rect"].collidepoint(event.pos):
                                    self.handle_action(button["action"])
                                    break
                        elif self.paused:
                            for button in reversed(self.buttons):
                                if button["rect"].collidepoint(event.pos):
                                    self.handle_action(button["action"])
                                    break
                        elif self.dialogue_open:
                            for button in reversed(self.buttons):
                                action = button["action"]
                                modal_action = (
                                    action == "close_dialogue"
                                    or (
                                        isinstance(action, tuple)
                                        and action[0] == "record_final_interview"
                                    )
                                )
                                if (
                                    modal_action
                                    and button["enabled"]
                                    and button["rect"].collidepoint(event.pos)
                                ):
                                    self.handle_action(action)
                                    break
                            else:
                                if self.dialogue_close_rect.collidepoint(event.pos):
                                    self.handle_action("close_dialogue")
                        elif self.selected_clue is not None:
                            for button in reversed(self.buttons):
                                if (
                                    button["enabled"]
                                    and button["rect"].collidepoint(event.pos)
                                ):
                                    self.handle_action(button["action"])
                                    break
                        else:
                            for button in reversed(self.buttons):
                                if (
                                    button["enabled"]
                                    and button["rect"].collidepoint(event.pos)
                                ):
                                    self.handle_action(button["action"])
                                    break

                elif event.type == pygame.MOUSEWHEEL:
                    pass

            if (
                self.level == 1
                and (self.paused or self.notebook_open or self.tutorial_open)
            ):
                self.jumble_last_tick = ticks

            self.reset_buttons()
            self.draw_header(mouse_pos, ticks)

            if self.notebook_open:
                self.draw_notebook()
            elif not self.paused:
                if self.level == 0:
                    self.draw_four_keys(mouse_pos, dt)
                elif self.level == 1:
                    self.draw_jumbled_message(mouse_pos)
                elif self.level == 2:
                    self.draw_secret_door(mouse_pos, dt)
                elif self.level == 3:
                    self.draw_level_3(mouse_pos)
                elif self.level == 4:
                    self.draw_aptitude_test(mouse_pos)
                elif self.level == 5:
                    self.draw_final_mystery(mouse_pos, dt)

                self.draw_footer()

            if self.paused:
                self.draw_pause_menu(mouse_pos)
            if self.tutorial_open:
                self.draw_first_time_guide(mouse_pos)

            pygame.display.flip()

        self.save_progress()
        return return_to_menu


if __name__ == "__main__":
    MindMazeGame().run()