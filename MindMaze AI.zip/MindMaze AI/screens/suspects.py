
import pygame

from config import (
    WIDTH, HEIGHT, BG, PANEL, PANEL_LIGHT, PURPLE, CYAN,
    GOLD, WHITE, MUTED, FONT_SMALL, FONT_BODY,
    FONT_BUTTON, FONT_HEADING
)
from game.case_data import SUSPECTS


class SuspectsScreen:
    def __init__(self, state):
        self.state = state
        self.selected_id = None

        self.back_button = pygame.Rect(25, 20, 130, 45)

        self.cards = {}
        card_width = 240
        gap = 20
        total_width = 4 * card_width + 3 * gap
        start_x = (WIDTH - total_width) // 2

        for i, suspect_id in enumerate(SUSPECTS):
            self.cards[suspect_id] = pygame.Rect(
                start_x + i * (card_width + gap),
                150,
                card_width,
                155
            )

    def draw_button(self, screen, rect, label, color):
        hovered = rect.collidepoint(pygame.mouse.get_pos())
        fill = tuple(min(c + 20, 255) for c in color) if hovered else color

        pygame.draw.rect(screen, fill, rect, border_radius=9)
        pygame.draw.rect(screen, WHITE, rect, 1, border_radius=9)

        text = FONT_SMALL.render(label, True, WHITE)
        screen.blit(text, text.get_rect(center=rect.center))

    def wrap_text(self, screen, text, x, y, max_width, color=WHITE):
        words = text.split()
        lines = []
        current = ""

        for word in words:
            candidate = (current + " " + word).strip()

            if FONT_BODY.size(candidate)[0] > max_width:
                lines.append(current)
                current = word
            else:
                current = candidate

        if current:
            lines.append(current)

        for line in lines:
            surface = FONT_BODY.render(line, True, color)
            screen.blit(surface, (x, y))
            y += 29

        return y

    def draw(self, screen):
        screen.fill(BG)

        self.draw_button(
            screen, self.back_button, "BACK", (65, 79, 108)
        )

        title = FONT_HEADING.render(
            "SUSPECT INTERROGATION", True, WHITE
        )
        screen.blit(title, title.get_rect(center=(WIDTH // 2, 65)))

        subtitle = FONT_SMALL.render(
            "Review each person's motive, alibi, and statement.",
            True, MUTED
        )
        screen.blit(subtitle, subtitle.get_rect(center=(WIDTH // 2, 105)))

        for suspect_id, rect in self.cards.items():
            suspect = SUSPECTS[suspect_id]
            selected = suspect_id == self.selected_id
            color = PANEL_LIGHT if selected else PANEL

            pygame.draw.rect(screen, color, rect, border_radius=14)
            pygame.draw.rect(
                screen, CYAN if selected else PURPLE,
                rect, 2, border_radius=14
            )

            # Stylized portrait placeholder
            center = (rect.centerx, rect.y + 43)
            pygame.draw.circle(screen, PURPLE, center, 23)
            pygame.draw.circle(screen, PANEL, center, 16)
            pygame.draw.circle(
                screen, CYAN, (center[0] - 6, center[1] - 3), 3
            )
            pygame.draw.circle(
                screen, CYAN, (center[0] + 6, center[1] - 3), 3
            )
            pygame.draw.arc(
                screen, WHITE,
                (center[0] - 8, center[1] + 2, 16, 10),
                3.3, 6.1, 2
            )

            name = FONT_BUTTON.render(
                suspect["name"], True, WHITE
            )
            screen.blit(
                name, name.get_rect(center=(rect.centerx, rect.y + 83))
            )

            role = FONT_SMALL.render(
                suspect["role"], True, GOLD
            )
            screen.blit(
                role, role.get_rect(center=(rect.centerx, rect.y + 116))
            )

            action = FONT_SMALL.render(
                "Click to inspect", True, MUTED
            )
            screen.blit(
                action, action.get_rect(center=(rect.centerx, rect.y + 140))
            )

        if self.selected_id:
            self.draw_profile(screen, self.selected_id)

    def draw_profile(self, screen, suspect_id):
        suspect = SUSPECTS[suspect_id]

        panel = pygame.Rect(110, 345, 880, 335)
        pygame.draw.rect(screen, PANEL, panel, border_radius=16)
        pygame.draw.rect(screen, PURPLE, panel, 2, border_radius=16)

        name = FONT_HEADING.render(suspect["name"], True, GOLD)
        screen.blit(name, (panel.x + 25, panel.y + 18))

        role = FONT_SMALL.render(suspect["role"], True, CYAN)
        screen.blit(role, (panel.x + 27, panel.y + 60))

        y = panel.y + 98

        for label, key in [
            ("MOTIVE", "motive"),
            ("ALIBI", "alibi"),
            ("STATEMENT", "statement"),
        ]:
            heading = FONT_BUTTON.render(label, True, PURPLE)
            screen.blit(heading, (panel.x + 25, y))
            y += 30

            y = self.wrap_text(
                screen,
                suspect[key],
                panel.x + 25,
                y,
                panel.width - 50
            )
            y += 12

            if y > panel.bottom - 20:
                break

    def handle_event(self, event):
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_ESCAPE:
                return "investigation"

        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            if self.back_button.collidepoint(event.pos):
                return "investigation"

            for suspect_id, rect in self.cards.items():
                if rect.collidepoint(event.pos):
                    self.selected_id = suspect_id
                    self.state["suspects_seen"].add(suspect_id)
                    break

        return None