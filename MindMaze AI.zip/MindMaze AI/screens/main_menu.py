import math
import random

import pygame

from config import (
    WIDTH, HEIGHT, BG, PANEL, PURPLE, CYAN, GOLD, WHITE, MUTED,
    FONT_SMALL, FONT_BODY, FONT_BUTTON, FONT_HEADING, FONT_TITLE
)


class MainMenu:
    def __init__(self):
        self.page = "menu"
        self.stars = [
            (
                random.randint(0, WIDTH),
                random.randint(0, HEIGHT),
                random.randint(1, 2),
                random.random() * math.tau,
            )
            for _ in range(85)
        ]
        self.buttons = {
            "investigation": pygame.Rect(585, 350, 345, 52),
            "how_to_play": pygame.Rect(585, 414, 345, 48),
            "case_file": pygame.Rect(585, 474, 345, 48),
            "quit": pygame.Rect(585, 534, 345, 44),
        }
        self.back_button = pygame.Rect(145, 570, 170, 44)

    def draw_background(self, screen):
        screen.fill(BG)
        ticks = pygame.time.get_ticks() / 800

        for x, y, size, phase in self.stars:
            brightness = int(90 + 100 * abs(math.sin(ticks + phase)))
            pygame.draw.circle(
                screen,
                (brightness // 2, brightness // 2, min(brightness, 255)),
                (x, y),
                size,
            )

        # Distant mansion skyline.
        for index, x in enumerate(range(0, WIDTH, 90)):
            building_height = 75 + (index * 53 % 125)
            building = pygame.Rect(
                x, HEIGHT - building_height, 68, building_height
            )
            pygame.draw.rect(screen, (13, 21, 39), building)
            for window_y in range(building.y + 15, HEIGHT - 15, 28):
                if (index + window_y) % 3:
                    pygame.draw.rect(
                        screen, (28, 42, 65),
                        (x + 12, window_y, 4, 8)
                    )

    def draw_button(self, screen, rect, label, color, action):
        hovered = rect.collidepoint(pygame.mouse.get_pos())
        fill = tuple(min(channel + 22, 255) for channel in color) if hovered else color
        border = CYAN if hovered else color

        pygame.draw.rect(screen, (6, 10, 22), rect.move(0, 4), border_radius=11)
        pygame.draw.rect(screen, fill, rect, border_radius=11)
        pygame.draw.rect(screen, border, rect, 2, border_radius=11)

        marker = "›" if action == "investigation" else "•"
        mark = FONT_BUTTON.render(marker, True, WHITE)
        screen.blit(mark, (rect.x + 18, mark.get_rect(centery=rect.centery).y))
        text = FONT_BUTTON.render(label, True, WHITE)
        screen.blit(
            text,
            text.get_rect(center=(rect.centerx + 12, rect.centery))
        )

    def draw_menu(self, screen, case_title):
        self.draw_background(screen)

        panel = pygame.Rect(115, 58, 870, 605)
        pygame.draw.rect(screen, (5, 9, 20), panel.move(0, 8), border_radius=24)
        pygame.draw.rect(screen, PANEL, panel, border_radius=24)
        pygame.draw.rect(screen, (57, 73, 109), panel, 1, border_radius=24)
        pygame.draw.line(screen, (48, 61, 91), (535, 100), (535, 620), 1)

        # Evidence-lens emblem.
        pygame.draw.circle(screen, (39, 35, 76), (310, 190), 63)
        pygame.draw.circle(screen, PURPLE, (310, 190), 44, 3)
        pygame.draw.circle(screen, CYAN, (310, 190), 28, 2)
        pygame.draw.line(screen, CYAN, (344, 224), (381, 261), 8)
        pygame.draw.circle(screen, GOLD, (310, 190), 5)

        eyebrow = FONT_SMALL.render("CASE FILE  /  01", True, GOLD)
        screen.blit(eyebrow, eyebrow.get_rect(center=(310, 294)))
        title_top = FONT_TITLE.render("MIND", True, WHITE)
        title_bottom = FONT_TITLE.render("MAZE", True, CYAN)
        screen.blit(title_top, title_top.get_rect(center=(310, 352)))
        screen.blit(title_bottom, title_bottom.get_rect(center=(310, 407)))

        tagline = FONT_BODY.render("Every clue has a story.", True, MUTED)
        screen.blit(tagline, tagline.get_rect(center=(310, 464)))
        pygame.draw.line(screen, PURPLE, (220, 505), (400, 505), 2)
        case_name = FONT_SMALL.render(case_title.upper(), True, GOLD)
        screen.blit(case_name, case_name.get_rect(center=(310, 535)))
        mode = FONT_SMALL.render("A SIX-CHAPTER DETECTIVE ADVENTURE", True, MUTED)
        screen.blit(mode, mode.get_rect(center=(310, 570)))

        section = FONT_SMALL.render("YOUR NEXT CASE", True, CYAN)
        screen.blit(section, (585, 122))
        heading = FONT_HEADING.render("The truth is hidden.", True, WHITE)
        screen.blit(heading, (585, 153))
        intro = FONT_BODY.render("Can you find it before the killer gets away?", True, MUTED)
        screen.blit(intro, (585, 192))

        steps = [
            ("01", "Find four mansion keys"),
            ("02", "Decode the jumbled message"),
            ("03", "Find the hidden key and true door"),
            ("04", "Crack the numeric vault"),
            ("05", "Solve detective challenges"),
            ("06", "Name the killer and location"),
        ]
        for index, (number, label) in enumerate(steps):
            y = 224 + index * 20
            number_image = FONT_SMALL.render(number, True, PURPLE)
            screen.blit(number_image, (590, y))
            label_image = FONT_SMALL.render(label, True, WHITE)
            screen.blit(label_image, (628, y))

        self.draw_button(
            screen, self.buttons["investigation"],
            "START INVESTIGATION", PURPLE, "investigation"
        )
        self.draw_button(
            screen, self.buttons["how_to_play"],
            "HOW TO PLAY", (38, 67, 96), "how_to_play"
        )
        self.draw_button(
            screen, self.buttons["case_file"],
            "READ CASE FILE", (34, 54, 79), "case_file"
        )
        self.draw_button(
            screen, self.buttons["quit"],
            "QUIT GAME", (56, 39, 57), "quit"
        )

    def draw_how_to_play(self, screen):
        self.draw_background(screen)
        panel = pygame.Rect(115, 58, 870, 605)
        pygame.draw.rect(screen, (5, 9, 20), panel.move(0, 8), border_radius=24)
        pygame.draw.rect(screen, PANEL, panel, border_radius=24)
        pygame.draw.rect(screen, (57, 73, 109), panel, 1, border_radius=24)

        eyebrow = FONT_SMALL.render("DETECTIVE FIELD GUIDE", True, GOLD)
        screen.blit(eyebrow, (155, 100))
        heading = FONT_TITLE.render("How to play", True, WHITE)
        screen.blit(heading, (155, 127))
        subtitle = FONT_BODY.render(
            "Move with your keyboard; use the mouse when a clue window opens.",
            True, MUTED
        )
        screen.blit(subtitle, (158, 190))

        chapters = [
            ("01", "THE FOUR KEYS", "Explore all four rooms; walk beside each glowing key and press E."),
            ("02", "JUMBLED MESSAGE", "Solve four shuffled words, 30 seconds each. Type and press Enter."),
            ("03", "SECRET DOOR", "Reveal symbols, open the hidden key compartment, then find the crescent-moon door."),
            ("04", "PASSWORD VAULT", "Enter the four-digit security-log time: 1005."),
            ("05", "APTITUDE TEST", "Answer five logic challenges; streaks unlock harder questions."),
            ("06", "FINAL MYSTERY", "Find the body, secure clues, interview suspects, solve timeline, accuse."),
        ]
        for index, (number, title, description) in enumerate(chapters):
            y = 224 + index * 51
            row = pygame.Rect(155, y, 790, 45)
            pygame.draw.rect(screen, (16, 27, 47), row, border_radius=10)
            pygame.draw.rect(screen, (44, 58, 87), row, 1, border_radius=10)
            badge = pygame.Rect(168, y + 5, 36, 35)
            pygame.draw.rect(screen, (49, 37, 87), badge, border_radius=8)
            number_image = FONT_BUTTON.render(number, True, CYAN)
            screen.blit(number_image, number_image.get_rect(center=badge.center))
            title_image = FONT_SMALL.render(title, True, WHITE)
            screen.blit(title_image, (220, y + 4))
            description_image = FONT_SMALL.render(description, True, MUTED)
            screen.blit(description_image, (220, y + 23))

        controls = FONT_SMALL.render(
            "WASD / arrows: move   E: interact   N: notebook   H: hint   P: pause   F1: guide",
            True, GOLD
        )
        screen.blit(controls, (158, 543))
        self.draw_button(
            screen, self.back_button, "BACK TO MENU",
            (38, 67, 96), "back"
        )

    def draw(self, screen, case_title):
        if self.page == "how_to_play":
            self.draw_how_to_play(screen)
        else:
            self.draw_menu(screen, case_title)

    def handle_event(self, event):
        if event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE:
            if self.page == "how_to_play":
                self.page = "menu"
                return None
            return "quit"

        if event.type != pygame.MOUSEBUTTONDOWN or event.button != 1:
            return None

        if self.page == "how_to_play":
            if self.back_button.collidepoint(event.pos):
                self.page = "menu"
            return None

        for action, rect in self.buttons.items():
            if rect.collidepoint(event.pos):
                if action == "how_to_play":
                    self.page = "how_to_play"
                    return None
                return action

        return None
