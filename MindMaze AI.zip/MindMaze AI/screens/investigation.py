
import pygame

from config import (
    WIDTH, HEIGHT, BG, PANEL, PANEL_LIGHT, PURPLE, CYAN,
    GOLD, WHITE, MUTED, RED, GREEN, FONT_SMALL, FONT_BODY,
    FONT_BUTTON, FONT_HEADING
)
from game.case_data import CLUES


class Investigation:
    def __init__(self, state):
        self.state = state

        # Interactive evidence locations
        self.objects = {
            "broken_clock": pygame.Rect(155, 210, 150, 105),
            "muddy_footprint": pygame.Rect(365, 390, 160, 90),
            "torn_letter": pygame.Rect(600, 220, 150, 100),
            "missing_key": pygame.Rect(815, 390, 120, 90),
        }

        self.suspects_button = pygame.Rect(805, 20, 260, 48)
        self.notebook_button = pygame.Rect(805, 78, 260, 42)
        self.menu_button = pygame.Rect(25, 20, 130, 45)
        self.close_button = pygame.Rect(805, 570, 240, 45)

        self.selected_clue = None
        self.notebook_open = False

    def draw_button(self, screen, rect, label, color):
        hovered = rect.collidepoint(pygame.mouse.get_pos())
        fill = tuple(min(c + 20, 255) for c in color) if hovered else color

        pygame.draw.rect(screen, fill, rect, border_radius=9)
        pygame.draw.rect(screen, WHITE, rect, 1, border_radius=9)

        text = FONT_SMALL.render(label, True, WHITE)
        screen.blit(text, text.get_rect(center=rect.center))

    def draw_room(self, screen):
        screen.fill(BG)

        # Wall and floor
        pygame.draw.rect(screen, (25, 32, 55), (0, 0, WIDTH, 490))
        pygame.draw.rect(screen, (35, 27, 47), (0, 490, WIDTH, 230))

        # Wall trim and floorboards
        pygame.draw.line(screen, PURPLE, (0, 490), (WIDTH, 490), 3)

        for y in range(520, HEIGHT, 45):
            pygame.draw.line(
                screen, (57, 42, 64), (0, y), (WIDTH, y), 1
            )

        for x in range(0, WIDTH, 125):
            pygame.draw.line(
                screen, (48, 38, 60), (x, 490), (x - 30, HEIGHT), 1
            )

        # Window with storm outside
        pygame.draw.rect(
            screen, (9, 16, 34), (435, 105, 180, 175), border_radius=8
        )
        pygame.draw.rect(
            screen, CYAN, (435, 105, 180, 175), 2, border_radius=8
        )
        pygame.draw.line(screen, CYAN, (525, 105), (525, 280), 2)
        pygame.draw.line(screen, CYAN, (435, 190), (615, 190), 2)

        # Desk
        pygame.draw.rect(
            screen, (95, 58, 55), (580, 335, 210, 28), border_radius=5
        )
        pygame.draw.rect(
            screen, (65, 43, 46), (600, 360, 18, 90)
        )
        pygame.draw.rect(
            screen, (65, 43, 46), (750, 360, 18, 90)
        )

        # Bookcase
        pygame.draw.rect(
            screen, (71, 45, 56), (35, 130, 100, 300), border_radius=5
        )

        for y in (205, 280, 355):
            pygame.draw.line(
                screen, GOLD, (40, y), (130, y), 3
            )

        # Decorative books
        book_colors = [RED, CYAN, PURPLE, GOLD]
        for row, y in enumerate((145, 220, 295, 370)):
            for i in range(4):
                pygame.draw.rect(
                    screen,
                    book_colors[(i + row) % len(book_colors)],
                    (44 + i * 21, y, 15, 48),
                    border_radius=2
                )

        # Room label
        label = FONT_HEADING.render("THE STUDY", True, WHITE)
        screen.blit(label, (30, 80))

        subtitle = FONT_SMALL.render(
            "Click the highlighted objects to inspect evidence.",
            True, MUTED
        )
        screen.blit(subtitle, (30, 115))

    def draw_clue_object(self, screen, clue_id, rect):
        discovered = clue_id in self.state["clues"]
        hovered = rect.collidepoint(pygame.mouse.get_pos())

        if clue_id == "broken_clock":
            pygame.draw.circle(screen, GOLD, rect.center, 38, 4)
            pygame.draw.circle(screen, PANEL_LIGHT, rect.center, 32)
            pygame.draw.circle(screen, GOLD, rect.center, 27, 2)
            pygame.draw.line(
                screen, WHITE, rect.center,
                (rect.centerx, rect.centery - 17), 3
            )
            pygame.draw.line(
                screen, WHITE, rect.center,
                (rect.centerx + 17, rect.centery + 7), 3
            )
            pygame.draw.line(
                screen, RED,
                (rect.centerx - 10, rect.centery - 10),
                (rect.centerx + 10, rect.centery + 10), 3
            )

        elif clue_id == "muddy_footprint":
            pygame.draw.ellipse(
                screen, (94, 72, 67),
                (rect.x + 25, rect.y + 20, 42, 56)
            )
            for i in range(4):
                pygame.draw.circle(
                    screen, (120, 94, 80),
                    (rect.x + 30 + i * 10, rect.y + 16), 6
                )

        elif clue_id == "torn_letter":
            pygame.draw.rect(
                screen, (228, 210, 166), rect.inflate(-12, -6),
                border_radius=3
            )
            for i in range(3):
                pygame.draw.line(
                    screen, (110, 83, 64),
                    (rect.x + 25, rect.y + 25 + i * 17),
                    (rect.right - 25, rect.y + 25 + i * 17), 2
                )

        elif clue_id == "missing_key":
            pygame.draw.circle(
                screen, GOLD, (rect.centerx - 14, rect.centery), 15, 5
            )
            pygame.draw.line(
                screen, GOLD,
                (rect.centerx, rect.centery),
                (rect.centerx + 35, rect.centery + 16), 6
            )
            pygame.draw.line(
                screen, GOLD,
                (rect.centerx + 20, rect.centery + 9),
                (rect.centerx + 23, rect.centery + 22), 5
            )

        if hovered:
            pygame.draw.rect(
                screen, CYAN, rect.inflate(12, 12), 2, border_radius=8
            )

        if discovered:
            pygame.draw.circle(
                screen, GREEN, (rect.right - 4, rect.top + 4), 10
            )
            draw_check = FONT_SMALL.render("✓", True, BG)
            screen.blit(
                draw_check,
                draw_check.get_rect(center=(rect.right - 4, rect.top + 4))
            )

        clue_label = FONT_SMALL.render(
            CLUES[clue_id]["title"], True,
            GREEN if discovered else WHITE
        )
        screen.blit(
            clue_label,
            clue_label.get_rect(center=(rect.centerx, rect.bottom + 18))
        )

    def draw_clue_panel(self, screen):
        if not self.selected_clue:
            return

        clue = CLUES[self.selected_clue]

        panel = pygame.Rect(185, 515, 590, 165)
        pygame.draw.rect(screen, PANEL, panel, border_radius=12)
        pygame.draw.rect(screen, CYAN, panel, 2, border_radius=12)

        title = FONT_HEADING.render(clue["title"], True, GOLD)
        screen.blit(title, (panel.x + 18, panel.y + 12))

        location = FONT_SMALL.render(
            "Location: " + clue["location"], True, CYAN
        )
        screen.blit(location, (panel.x + 18, panel.y + 53))

        # Wrap the description across lines
        words = clue["description"].split()
        lines = []
        current = ""

        for word in words:
            candidate = (current + " " + word).strip()
            if FONT_SMALL.size(candidate)[0] > panel.width - 36:
                lines.append(current)
                current = word
            else:
                current = candidate

        if current:
            lines.append(current)

        for i, line in enumerate(lines[:3]):
            text = FONT_SMALL.render(line, True, WHITE)
            screen.blit(text, (panel.x + 18, panel.y + 80 + i * 22))

        self.draw_button(
            screen, self.close_button, "CLOSE CLUE", (68, 83, 115)
        )

    def draw_notebook(self, screen):
        overlay = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
        overlay.fill((5, 8, 20, 225))
        screen.blit(overlay, (0, 0))

        panel = pygame.Rect(150, 95, 800, 530)
        pygame.draw.rect(screen, PANEL, panel, border_radius=18)
        pygame.draw.rect(screen, PURPLE, panel, 2, border_radius=18)

        title = FONT_HEADING.render("DETECTIVE NOTEBOOK", True, GOLD)
        screen.blit(title, (panel.x + 28, panel.y + 22))

        found = self.state["clues"]
        progress = FONT_BODY.render(
            f"Evidence discovered: {len(found)}/{len(CLUES)}",
            True, CYAN
        )
        screen.blit(progress, (panel.x + 28, panel.y + 72))

        y = panel.y + 125

        if not found:
            draw_text = FONT_BODY.render(
                "No evidence yet. Inspect the objects in the study.",
                True, MUTED
            )
            screen.blit(draw_text, (panel.x + 28, y))
        else:
            for clue_id in found:
                clue = CLUES[clue_id]
                text = FONT_BODY.render(
                    "• " + clue["title"] + " — " + clue["location"],
                    True, WHITE
                )
                screen.blit(text, (panel.x + 28, y))
                y += 48

        hint = FONT_SMALL.render(
            "Press N or click Notebook to return to the investigation.",
            True, MUTED
        )
        screen.blit(hint, (panel.x + 28, panel.bottom - 45))

    def handle_event(self, event):
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_n:
                self.notebook_open = not self.notebook_open
                return None

            if event.key == pygame.K_ESCAPE:
                if self.notebook_open:
                    self.notebook_open = False
                elif self.selected_clue:
                    self.selected_clue = None
                else:
                    return "menu"

        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            if self.notebook_open:
                self.notebook_open = False
                return None

            if self.selected_clue:
                if self.close_button.collidepoint(event.pos):
                    self.selected_clue = None
                return None

            if self.menu_button.collidepoint(event.pos):
                return "menu"

            if self.suspects_button.collidepoint(event.pos):
                return "suspects"

            if self.notebook_button.collidepoint(event.pos):
                self.notebook_open = True
                return None

            for clue_id, rect in self.objects.items():
                if rect.collidepoint(event.pos):
                    self.state["clues"].add(clue_id)
                    self.selected_clue = clue_id
                    return None

        return None

    def draw(self, screen):
        self.draw_room(screen)

        self.draw_button(
            screen, self.menu_button, "MAIN MENU", (65, 79, 108)
        )
        self.draw_button(
            screen, self.suspects_button, "VIEW SUSPECTS", PURPLE
        )
        self.draw_button(
            screen, self.notebook_button, "DETECTIVE NOTEBOOK", (54, 103, 145)
        )

        for clue_id, rect in self.objects.items():
            self.draw_clue_object(screen, clue_id, rect)

        status = FONT_SMALL.render(
            f"Evidence: {len(self.state['clues'])}/{len(CLUES)}",
            True, GREEN
        )
        screen.blit(status, (30, HEIGHT - 30))

        if self.selected_clue:
            self.draw_clue_panel(screen)

        if self.notebook_open:
            self.draw_notebook(screen)