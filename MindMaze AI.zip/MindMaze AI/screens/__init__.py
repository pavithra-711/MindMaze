
import math
import random
import pygame

from config import (
    WIDTH, HEIGHT, BG, PANEL, PURPLE, CYAN, GOLD,
    WHITE, MUTED, FONT_SMALL, FONT_BODY, FONT_BUTTON,
    FONT_TITLE, FONT_HEADING
)


class MainMenu:
    def __init__(self):
        self.stars = [
            (
                random.randint(0, WIDTH),
                random.randint(0, HEIGHT),
                random.randint(1, 3),
                random.random() * math.pi * 2,
            )
            for _ in range(90)
        ]

        self.play_rect = pygame.Rect(380, 390, 340, 62)
        self.case_rect = pygame.Rect(380, 470, 340, 55)
        self.quit_rect = pygame.Rect(380, 540, 340, 48)

    def draw_background(self, screen):
        screen.fill(BG)
        now = pygame.time.get_ticks() / 700

        for x, y, size, phase in self.stars:
            glow = int(150 + 100 * abs(math.sin(now + phase)))
            pygame.draw.circle(
                screen,
                (glow // 2, glow // 2, min(glow, 255)),
                (x, y),
                size,
            )

        # Distant city silhouettes
        for x in range(0, WIDTH, 100):
            building_height = 90 + (x * 13 % 180)
            pygame.draw.rect(
                screen,
                (21, 28, 48),
                (x, HEIGHT - building_height, 80, building_height),
            )

    def draw_button(self, screen, rect, label, color):
        hovered = rect.collidepoint(pygame.mouse.get_pos())
        fill = tuple(min(c + 25, 255) for c in color) if hovered else color

        pygame.draw.rect(screen, fill, rect, border_radius=12)
        pygame.draw.rect(screen, WHITE, rect, 1, border_radius=12)

        text = FONT_BUTTON.render(label, True, WHITE)
        screen.blit(text, text.get_rect(center=rect.center))

    def handle_event(self, event):
        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            if self.play_rect.collidepoint(event.pos):
                return "investigation"

            if self.case_rect.collidepoint(event.pos):
                return "case_file"

            if self.quit_rect.collidepoint(event.pos):
                return "quit"

        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_RETURN:
                return "investigation"

            if event.key == pygame.K_ESCAPE:
                return "quit"

        return None

    def draw(self, screen, case_title):
        self.draw_background(screen)

        panel = pygame.Rect(180, 90, 740, 555)
        pygame.draw.rect(screen, PANEL, panel, border_radius=24)
        pygame.draw.rect(screen, PURPLE, panel, 2, border_radius=24)

        title = FONT_TITLE.render("MIND MAZE AI", True, WHITE)
        screen.blit(title, title.get_rect(center=(WIDTH // 2, 190)))

        subtitle = FONT_HEADING.render(
            "MURDER MYSTERY DIVISION", True, CYAN
        )
        screen.blit(subtitle, subtitle.get_rect(center=(WIDTH // 2, 250)))

        case_text = FONT_BODY.render(case_title, True, GOLD)
        screen.blit(case_text, case_text.get_rect(center=(WIDTH // 2, 305)))

        description = FONT_SMALL.render(
            "Investigate evidence. Question suspects. Find the truth.",
            True, MUTED
        )
        screen.blit(
            description,
            description.get_rect(center=(WIDTH // 2, 345))
        )

        self.draw_button(screen, self.play_rect, "START INVESTIGATION", PURPLE)
        self.draw_button(screen, self.case_rect, "READ CASE FILE", (54, 103, 145))
        self.draw_button(screen, self.quit_rect, "QUIT GAME", (111, 48, 68))

        footer = FONT_SMALL.render(
            "A detective adventure prototype", True, MUTED
        )
        screen.blit(footer, footer.get_rect(center=(WIDTH // 2, 620)))