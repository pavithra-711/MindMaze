CASE_TITLE = "The Midnight Murder"

CASE_INTRO = (
    "Dr. Adrian Vale, a famous scientist, was found dead "
    "in his locked mansion at 11:30 PM during a storm. "
    "Four people were in the mansion. Investigate the "
    "evidence and discover whose story does not add up."
)

CLUES = {
    "broken_clock": {
        "title": "The Broken Clock",
        "description": "The study clock stopped at 10:45 PM. Its hands may have been moved.",
        "location": "Study",
    },
    "muddy_footprint": {
        "title": "Muddy Footprint",
        "description": "A muddy shoeprint was found near the library window.",
        "location": "Library",
    },
    "torn_letter": {
        "title": "Torn Letter",
        "description": "The letter says: Meet me in the study before eleven. Come alone.",
        "location": "Study",
    },
    "missing_key": {
        "title": "Missing Key",
        "description": "The study's spare key is missing from its usual place.",
        "location": "Hallway",
    },
}

SUSPECTS = {
    "elena": {
        "name": "Elena Vale",
        "role": "The Daughter",
        "motive": "She argued with Adrian over his inheritance.",
        "alibi": "She claims she was in the drawing room at 10:45 PM.",
        "statement": "I never entered the study that evening.",
    },
    "marcus": {
        "name": "Marcus Reed",
        "role": "The Business Partner",
        "motive": "Adrian planned to expose a financial dispute.",
        "alibi": "He says he was in the conservatory.",
        "statement": "I was nowhere near the study.",
    },
    "iris": {
        "name": "Dr. Iris Shaw",
        "role": "The Research Assistant",
        "motive": "Adrian intended to publish research without crediting her.",
        "alibi": "She says she was organizing laboratory papers.",
        "statement": "The study clock was already broken.",
    },
    "thomas": {
        "name": "Thomas Gray",
        "role": "The Butler",
        "motive": "Adrian threatened to dismiss him.",
        "alibi": "He claims he was preparing the dining room.",
        "statement": "I locked the front entrance before the storm.",
    },
}

CASE_SOLUTION = {
    "culprit": "iris",
    "reason": "Prototype story solution; deduction gameplay is not yet implemented.",
}