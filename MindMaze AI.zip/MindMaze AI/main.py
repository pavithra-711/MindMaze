
import sys
import pygame

from config import (
    WIDTH, HEIGHT, FPS, TITLE, BG, PANEL, PURPLE, CYAN,
    GOLD, WHITE, MUTED, FONT_BODY, FONT_HEADING, FONT_SMALL
)
from game.case_data import CASE_TITLE, CASE_INTRO, CLUES
from screens.main_menu import MainMenu
from screens.investigation import Investigation
from screens.suspects import SuspectsScreen


def draw_case_file(screen, back_button):
    screen.fill(BG)

    panel = pygame.Rect(120, 100, 860, 500)
    pygame.draw.rect(screen, PANEL, panel, border_radius=18)
    pygame.draw.rect(screen, PURPLE, panel, 2, border_radius=18)

    title = FONT_HEADING.render("CONFIDENTIAL CASE FILE", True, GOLD)
    screen.blit(title, title.get_rect(center=(WIDTH // 2, 155)))

    case_name = FONT_BODY.render(CASE_TITLE, True, CYAN)
    screen.blit(case_name, case_name.get_rect(center=(WIDTH // 2, 215)))

    # Wrap the introduction to fit the panel
    words = CASE_INTRO.split()
    lines = []
    current = ""

    for word in words:
        candidate = (current + " " + word).strip()
        if FONT_BODY.size(candidate)[0] > 730:
            lines.append(current)
            current = word
        else:
            current = candidate

    if current:
        lines.append(current)

    y = 270
    for line in lines:
        text = FONT_BODY.render(line, True, WHITE)
        screen.blit(text, text.get_rect(center=(WIDTH // 2, y)))
        y += 35

    details = [
        "Victim: Dr. Adrian Vale",
        "Location: Vale Mansion",
        "Estimated discovery: 11:30 PM",
        f"Evidence items to investigate: {len(CLUES)}",
    ]

    y += 25
    for detail in details:
        text = FONT_SMALL.render(detail, True, MUTED)
        screen.blit(text, text.get_rect(center=(WIDTH // 2, y)))
        y += 27

    pygame.draw.rect(screen, (65, 79, 108), back_button, border_radius=8)
    label = FONT_SMALL.render("BACK TO MENU", True, WHITE)
    screen.blit(label, label.get_rect(center=back_button.center))


def main():
    pygame.init()

    screen = pygame.display.set_mode((WIDTH, HEIGHT))
    pygame.display.set_caption(TITLE)
    clock = pygame.time.Clock()

    # Shared state persists when the player changes screens.
    state = {
        "clues": set(),
        "suspects_seen": set(),
    }

    menu = MainMenu()
    investigation = Investigation(state)
    suspects_screen = SuspectsScreen(state)

    current_screen = "menu"
    case_back_button = pygame.Rect(30, 25, 150, 45)

    running = True

    while running:
        clock.tick(FPS)

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
                continue

            result = None

            if current_screen == "menu":
                result = menu.handle_event(event)

            elif current_screen == "investigation":
                result = investigation.handle_event(event)

            elif current_screen == "suspects":
                result = suspects_screen.handle_event(event)

            elif current_screen == "case_file":
                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_ESCAPE:
                        result = "menu"

                if (
                    event.type == pygame.MOUSEBUTTONDOWN
                    and event.button == 1
                    and case_back_button.collidepoint(event.pos)
                ):
                    result = "menu"

            if result == "quit":
                running = False

            elif current_screen == "menu" and result == "investigation":
                from screens.four_levels import MindMazeGame

                return_to_menu = MindMazeGame().run()
                pygame.display.set_caption(TITLE)
                if not return_to_menu:
                    running = False

            elif result in (
                "menu", "investigation", "suspects", "case_file"
            ):
                current_screen = result

        if current_screen == "menu":
            menu.draw(screen, CASE_TITLE)

        elif current_screen == "investigation":
            investigation.draw(screen)

        elif current_screen == "suspects":
            suspects_screen.draw(screen)

        elif current_screen == "case_file":
            draw_case_file(screen, case_back_button)

        # Always display a small progress indicator.
        progress = FONT_SMALL.render(
            f"Clues: {len(state['clues'])}/{len(CLUES)}",
            True, CYAN
        )
        screen.blit(progress, (WIDTH - 150, HEIGHT - 27))

        pygame.display.flip()

    pygame.quit()
    sys.exit()


if __name__ == "__main__":
    main()