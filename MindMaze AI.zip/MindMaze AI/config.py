
import pygame

WIDTH = 1100
HEIGHT = 720
FPS = 60
TITLE = "Mind Maze AI | Murder Mystery"

# Theme
BG = (14, 18, 35)
PANEL = (27, 34, 57)
PANEL_LIGHT = (38, 47, 74)
PURPLE = (153, 105, 255)
CYAN = (86, 224, 245)
GOLD = (255, 204, 112)
RED = (255, 100, 120)
GREEN = (104, 230, 170)
WHITE = (242, 245, 255)
MUTED = (165, 177, 200)
DARK = (9, 12, 25)

pygame.font.init()

FONT_SMALL = pygame.font.SysFont("arial", 16)
FONT_BODY = pygame.font.SysFont("arial", 20)
FONT_BUTTON = pygame.font.SysFont("arial", 21, bold=True)
FONT_HEADING = pygame.font.SysFont("arial", 32, bold=True)
FONT_TITLE = pygame.font.SysFont("arial", 54, bold=True)